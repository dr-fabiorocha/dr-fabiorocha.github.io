var cors = require('cors')

var express = require('express');
var app = express();

app.use(cors())

var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.post('/', function(req, res){
    let a = req.body.data;
    let b = req.body.msg;
    console.log(a+b)
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end('thanks');
});

port = 20000;
app.listen(port);
console.log('SERVIDOR RODANDO EM http://localhost:' + port)
console.log('\n')

