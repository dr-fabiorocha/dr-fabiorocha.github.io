function Temperatura (ID, ID2, SUP, INF)
{
  this.registra();
  this.temperaturaINF = INF;
  this.temperaturaSUP = SUP;


	var vetorAmostras = Array();
	var qtdPontos;
	var canvas = document.getElementById(ID);
    var ctx    = canvas.getContext('2d');


    this.resize = function ()
    {
        this.setHeightWidth( (window.innerHeight-150), window.innerWidth);
    };
    this.setHeightWidth=  function(H,W)
	{
		qtdPontos    = W;
        canvas.style.width ='100%';
        canvas.style.height='100%';
        canvas.width  = W;
        canvas.height = H;
	};
	this.novaAmostra=  function(amostra)
	{
	    document.getElementById(ID2).innerHTML = amostra+"&#8451;";
		
		if (vetorAmostras.length==qtdPontos)   vetorAmostras.splice(0, 1);
		vetorAmostras.push( amostra ) ;
		
		this.atualizaGrafico();
	};	

	this.atualizaGrafico=  function()
	{
		ctx.clearRect(0, 0, canvas.width,canvas.height);
		ctx.strokeStyle = "red"; 
		ctx.lineWidth   = "2";
  	ctx.fillStyle   = 'blue';
		
		var coord_y;
		


      var escala = canvas.height/(SUP-INF);
      var y_old=vetorAmostras[1];
        y_old = ( y_old-INF)*escala;
          y_old =   canvas.height -  y_old;
			for (var coord_x = 1; coord_x< qtdPontos; coord_x++)
			{
         coord_y =   vetorAmostras[coord_x];
         coord_y = (coord_y-INF)*escala;
         coord_y =   canvas.height - coord_y;
		 		 ctx.beginPath();
         ctx.moveTo(coord_x-1,y_old);
         ctx.lineTo(coord_x,coord_y);
         y_old = coord_y;
         ctx.stroke();

			}	
    

ctx.stroke();



		
	};
}
// -------------------- Registra funcoes ------------------------
Temperatura.prototype.registra = function () {
  // inicializa
  PubSub.subscribe('initialize', function (msg, data) {
    LOG('>>Temperatura > initialize')
    PubSub.publish('LegendaTemperatura',{superior:this.temperaturaSUP,inferior:this.temperaturaINF,legenda:''});
  }.bind(this))

  PubSub.subscribe('resize', function (msg, informacao) {
    LOG('>>Temperatura > resize')
    this.resize();
  }.bind(this))

}
