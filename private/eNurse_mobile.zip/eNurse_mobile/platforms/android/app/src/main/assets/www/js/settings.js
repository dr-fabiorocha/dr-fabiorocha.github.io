/* ******************************************************************************************************************************************************************************** */
/* ******************************************************************************  Settings *************************************************************************************** */

var settings = {fever:38, hipothermia:35, alarm:0};


function loadSavedSettings ()
{
	if (localStorage.getItem("settings") === null)
	{
		saveSettings();
	}
	else {
			var tmp = window.localStorage.getItem('settings');
			settings = JSON.parse(tmp);
	}
}

function saveSettings()
{
	window.localStorage.setItem('settings', JSON.stringify(settings));
}

function updateFever(newVal)
{
	settings.fever = newVal;
}

function updateHipothermia(newVal)
{
	settings.hipothermia = newVal;
}



function showTemperature (value)
{
	return value+"&deg;C";
}





function changeAlarm(id)
{
	//if (eh_mobile) beep(); //navigator.vibrate(3000);
	//else beep();

	var x = document.getElementById(id);
	if (x.checked==true)  settings.alarm=1;
	else settings.alarm=0;
}

function updateTemperature()
{

	document.getElementById('slider_hipothermia').value             = settings.hipothermia;
	document.getElementById('slider_fever').value                   = settings.fever;
}

function updateAlarm()
{
	if (settings.alarm==1) document.getElementById('alarm').checked=true;
	else  document.getElementById('alarm').checked=false;
}

function updateSettings()
{
	updateTemperature();
	updateAlarm();
}

