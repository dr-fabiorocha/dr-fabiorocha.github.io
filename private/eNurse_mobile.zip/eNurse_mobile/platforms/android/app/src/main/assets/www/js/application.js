// TODO - Aplicacao do celular esta com problema
// conexao e perde conexao


var servidorWebserver          = "ws://enurse:81";
var websocket;
var vtesta;



var eh_mobile;

var zeroconf;
var perdeuConexao;
var url;
var timerID = 0;



function disparaDNS() {
    zeroconf = cordova.plugins.zeroconf;
        zeroconf.registerAddressFamily = 'ipv4'; // or 'ipv6' ('any' by default)
zeroconf.watchAddressFamily = 'ipv4'; // or 'ipv6' ('any' by default)
    LOG('disparaDNS')
    //zeroconf.watch('_ws._tcp.local.', function(result) {
zeroconf.watch('_esp._tcp.local', 'local', function(result) {
     
        let action = result.action;
        let service = result.service;

        if ((service.name) == "enurse") {
            servidorWebserver = service.application + "://" + service.addresses[0] + ":" + service.port;
                    load(service.application + "://" + service.addresses[0] + ":" + service.port);

        }
    });
}


// ************************************** PERDA DE CONEXAO **************************************
function perdaConexao() {
    websocket.close();
    console.log("PEDEU CONEXAO");
   

    if (eh_mobile) diparaDNS();
    inicializa_conexao();


}

function termina() {
    window.close();
    navigator.app.exitApp();
}
// **********************************************************************************************





function beep() {
    //var snd = new Audio("data:audio/wav;base64,//uQRAAAAWMSLwUIYAAsYkXgoQwAEaYLWfkWgAI0wWs/ItAAAGDgYtAgAyN+QWaAAihwMWm4G8QQRDiMcCBcH3Cc+CDv/7xA4Tvh9Rz/y8QADBwMWgQAZG/	ILNAARQ4GLTcDeIIIhxGOBAuD7hOfBB3/94gcJ3w+o5/5eIAIAAAVwWgQAVQ2ORaIQwEMAJiDg95G4nQL7mQVWI6GwRcfsZAcsKkJvxgxEjzFUgfHoSQ9Qq7KNwqHwuB13MA4a1q/DmBrHgPcmjiGoh//EwC5nGPEmS4RcfkVKOhJf+WOgoxJclFz3kgn//dBA+ya1GhurNn8zb//9NNutNuhz31f////9vt///z+IdAEAAAK4LQIAKobHItEIYCGAExBwe8jcToF9zIKrEdDYIuP2MgOWFSE34wYiR5iqQPj0JIeoVdlG4VD4XA67mAcNa1fhzA1jwHuTRxDUQ//iYBczjHiTJcIuPyKlHQkv/LHQUYkuSi57yQT//uggfZNajQ3Vmz+Zt//+mm3Wm3Q576v////+32///5/EOgAAADVghQAAAAA//uQZAUAB1WI0PZugAAAAAoQwAAAEk3nRd2qAAAAACiDgAAAAAAABCqEEQRLCgwpBGMlJkIz8jKhGvj4k6jzRnqasNKIeoh5gI7BJaC1A1AoNBjJgbyApVS4IDlZgDU5WUAxEKDNmmALHzZp0Fkz1FMTmGFl1FMEyodIavcCAUHDWrKAIA4aa2oCgILEBupZgHvAhEBcZ6joQBxS76AgccrFlczBvKLC0QI2cBoCFvfTDAo7eoOQInqDPBtvrDEZBNYN5xwNwxQRfw8ZQ5wQVLvO8OYU+mHvFLlDh05Mdg7BT6YrRPpCBznMB2r//xKJjyyOh+cImr2/4doscwD6neZjuZR4AgAABYAAAABy1xcdQtxYBYYZdifkUDgzzXaXn98Z0oi9ILU5mBjFANmRwlVJ3/6jYDAmxaiDG3/6xjQQCCKkRb/6kg/wW+kSJ5//rLobkLSiKmqP/0ikJuDaSaSf/6JiLYLEYnW/+kXg1WRVJL/9EmQ1YZIsv/6Qzwy5qk7/+tEU0nkls3/zIUMPKNX/6yZLf+kFgAfgGyLFAUwY//uQZAUABcd5UiNPVXAAAApAAAAAE0VZQKw9ISAAACgAAAAAVQIygIElVrFkBS+Jhi+EAuu+lKAkYUEIsmEAEoMeDmCETMvfSHTGkF5RWH7kz/ESHWPAq/kcCRhqBtMdokPdM7vil7RG98A2sc7zO6ZvTdM7pmOUAZTnJW+NXxqmd41dqJ6mLTXxrPpnV8avaIf5SvL7pndPvPpndJR9Kuu8fePvuiuhorgWjp7Mf/PRjxcFCPDkW31srioCExivv9lcwKEaHsf/7ow2Fl1T/9RkXgEhYElAoCLFtMArxwivDJJ+bR1HTKJdlEoTELCIqgEwVGSQ+hIm0NbK8WXcTEI0UPoa2NbG4y2K00JEWbZavJXkYaqo9CRHS55FcZTjKEk3NKoCYUnSQ0rWxrZbFKbKIhOKPZe1cJKzZSaQrIyULHDZmV5K4xySsDRKWOruanGtjLJXFEmwaIbDLX0hIPBUQPVFVkQkDoUNfSoDgQGKPekoxeGzA4DUvnn4bxzcZrtJyipKfPNy5w+9lnXwgqsiyHNeSVpemw4bWb9psYeq//uQZBoABQt4yMVxYAIAAAkQoAAAHvYpL5m6AAgAACXDAAAAD59jblTirQe9upFsmZbpMudy7Lz1X1DYsxOOSWpfPqNX2WqktK0DMvuGwlbNj44TleLPQ+Gsfb+GOWOKJoIrWb3cIMeeON6lz2umTqMXV8Mj30yWPpjoSa9ujK8SyeJP5y5mOW1D6hvLepeveEAEDo0mgCRClOEgANv3B9a6fikgUSu/DmAMATrGx7nng5p5iimPNZsfQLYB2sDLIkzRKZOHGAaUyDcpFBSLG9MCQALgAIgQs2YunOszLSAyQYPVC2YdGGeHD2dTdJk1pAHGAWDjnkcLKFymS3RQZTInzySoBwMG0QueC3gMsCEYxUqlrcxK6k1LQQcsmyYeQPdC2YfuGPASCBkcVMQQqpVJshui1tkXQJQV0OXGAZMXSOEEBRirXbVRQW7ugq7IM7rPWSZyDlM3IuNEkxzCOJ0ny2ThNkyRai1b6ev//3dzNGzNb//4uAvHT5sURcZCFcuKLhOFs8mLAAEAt4UWAAIABAAAAAB4qbHo0tIjVkUU//uQZAwABfSFz3ZqQAAAAAngwAAAE1HjMp2qAAAAACZDgAAAD5UkTE1UgZEUExqYynN1qZvqIOREEFmBcJQkwdxiFtw0qEOkGYfRDifBui9MQg4QAHAqWtAWHoCxu1Yf4VfWLPIM2mHDFsbQEVGwyqQoQcwnfHeIkNt9YnkiaS1oizycqJrx4KOQjahZxWbcZgztj2c49nKmkId44S71j0c8eV9yDK6uPRzx5X18eDvjvQ6yKo9ZSS6l//8elePK/Lf//IInrOF/FvDoADYAGBMGb7FtErm5MXMlmPAJQVgWta7Zx2go+8xJ0UiCb8LHHdftWyLJE0QIAIsI+UbXu67dZMjmgDGCGl1H+vpF4NSDckSIkk7Vd+sxEhBQMRU8j/12UIRhzSaUdQ+rQU5kGeFxm+hb1oh6pWWmv3uvmReDl0UnvtapVaIzo1jZbf/pD6ElLqSX+rUmOQNpJFa/r+sa4e/pBlAABoAAAAA3CUgShLdGIxsY7AUABPRrgCABdDuQ5GC7DqPQCgbbJUAoRSUj+NIEig0YfyWUho1VBBBA//uQZB4ABZx5zfMakeAAAAmwAAAAF5F3P0w9GtAAACfAAAAAwLhMDmAYWMgVEG1U0FIGCBgXBXAtfMH10000EEEEEECUBYln03TTTdNBDZopopYvrTTdNa325mImNg3TTPV9q3pmY0xoO6bv3r00y+IDGid/9aaaZTGMuj9mpu9Mpio1dXrr5HERTZSmqU36A3CumzN/9Robv/Xx4v9ijkSRSNLQhAWumap82WRSBUqXStV/YcS+XVLnSS+WLDroqArFkMEsAS+eWmrUzrO0oEmE40RlMZ5+ODIkAyKAGUwZ3mVKmcamcJnMW26MRPgUw6j+LkhyHGVGYjSUUKNpuJUQoOIAyDvEyG8S5yfK6dhZc0Tx1KI/gviKL6qvvFs1+bWtaz58uUNnryq6kt5RzOCkPWlVqVX2a/EEBUdU1KrXLf40GoiiFXK///qpoiDXrOgqDR38JB0bw7SoL+ZB9o1RCkQjQ2CBYZKd/+VJxZRRZlqSkKiws0WFxUyCwsKiMy7hUVFhIaCrNQsKkTIsLivwKKigsj8XYlwt/WKi2N4d//uQRCSAAjURNIHpMZBGYiaQPSYyAAABLAAAAAAAACWAAAAApUF/Mg+0aohSIRobBAsMlO//Kk4soosy1JSFRYWaLC4qZBYWFRGZdwqKiwkNBVmoWFSJkWFxX4FFRQWR+LsS4W/rFRb/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////VEFHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU291bmRib3kuZGUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjAwNGh0dHA6Ly93d3cuc291bmRib3kuZGUAAAAAAAAAACU=");
    //snd.play();
    //var audio = new Audio('audio/audio_file.mp3');
    //audio.play();
}



function periodica ()
{
  mostraModal();
}

function limpaWatchDog()
{
    removeConectando();
    clearInterval(vtesta);
    vtesta=setInterval(mostraModal, 9000);
}




function load(parametro) {
    url = parametro;
    inicializa_conexao(url);
    
}

	function removeConectando() {
		let list1 = document.getElementsByClassName("conectando");
		for (var i = 0; i < list1.length; i++) list1[i].style.display = "none";
		let list2 = document.getElementsByClassName("informacaovisivel");
		for (var i = 0; i < list2.length; i++) list2[i].style.display = "block";
	}

	function mostraModal() {
        if (websocket) {
            //websocket.open();
        } 
        inicializa_conexao();
		let list1 = document.getElementsByClassName("conectando");
		for (var i = 0; i < list1.length; i++) list1[i].style.display = "block";
		let list2 = document.getElementsByClassName("informacaovisivel");
		for (var i = 0; i < list2.length; i++) list2[i].style.display = "none";
  	}


function startRede ()
{
    if( isCordovaApp)  disparaDNS();
    mostraModal();
   // inicializa_conexao();

        vtesta=setInterval(mostraModal, 9000);


}

function inicializa_conexao()
{
  LOG('inicializa_conexao')
  if (websocket != undefined) {
     if (websocket.close != undefined) websocket.close()
   }
  websocket = new  ReconnectingWebSocket(servidorWebserver,null, {reconnectInterval: 30000, timeoutInterval: 20000});
	websocket.binaryType = 'arraybuffer';
  websocket.onopen    = function(evt) { onOpen(evt)    };
	websocket.onclose   = function(code, reason) { onClose(code, reason)   };
	websocket.onmessage = function(evt) { onMessage(evt) };
	websocket.onerror   = function(evt) { onError(evt)   };	
}

function onOpen(evt) 
{
    LOG('Open')
    removeConectando();
}
function onClose(code, reason) {
   LOG('Close')
}
function onError(evt) {
   LOG('Error')
}

function onMessage(evt)	{
		var bytearray =[];

		limpaWatchDog();
    bytearray = evt.data;
	 LOG('Recebeu Msg')
		switch ( bytearray[0]) {
			case 'T': // Temperatura
       let valor = bytearray[1].charCodeAt(0)+(bytearray[2].charCodeAt(0))/100;
				temperatura.novaAmostra(valor);

				break;
			
		 
    } 
}

// **********************************************************************************************




