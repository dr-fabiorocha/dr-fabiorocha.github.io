cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-headercolor.HeaderColor",
    "file": "plugins/cordova-plugin-headercolor/www/HeaderColor.js",
    "pluginId": "cordova-plugin-headercolor",
    "clobbers": [
      "cordova.plugins.headerColor"
    ]
  },
  {
    "id": "cordova-plugin-zeroconf.ZeroConf",
    "file": "plugins/cordova-plugin-zeroconf/www/zeroconf.js",
    "pluginId": "cordova-plugin-zeroconf",
    "clobbers": [
      "cordova.plugins.zeroconf"
    ]
  },
  {
    "id": "cordova-plugin-native-spinner.SpinnerDialog",
    "file": "plugins/cordova-plugin-native-spinner/www/SpinnerDialog.js",
    "pluginId": "cordova-plugin-native-spinner",
    "clobbers": [
      "SpinnerDialog"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-headercolor": "1.0",
  "cordova-plugin-add-swift-support": "1.7.1",
  "cordova-plugin-zeroconf": "1.3.1",
  "cordova-plugin-native-spinner": "1.1.3"
};
// BOTTOM OF METADATA
});