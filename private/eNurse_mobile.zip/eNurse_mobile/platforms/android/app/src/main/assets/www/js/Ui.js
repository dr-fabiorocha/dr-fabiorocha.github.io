
'use strict'

var elSetFr = document.querySelector('.set-en');
var elSetEnUs = document.querySelector('.set-pt-br');
var defaultLocale = 'pt-br';

function setupHTML() {
  var pref = (phonon.i18n().getPreference() ? phonon.i18n().getPreference() : 'not used');
  phonon.i18n().bind();
}

var setPreference = function (evt) {
  var target = evt.target;
  var lang = target.getAttribute('data-l');
  if(lang) {
    phonon.updateLocale(lang);
  }
};






function Ui (releaseInfo) {
         LOG('>>Ui>create')

  this.releaseInfo = releaseInfo
  this.appPhonon        = null
  phonon.options({
    navigator: {
      defaultPage: 'home',
      defaultTemplateExtension: 'html',
      animatePages: false,
      enableBrowserBackButton: true,
      templateRootDirectory: './'
    },
     i18n: {
    directory: 'res/lang/',
    localeFallback: defaultLocale,
    localePreferred: 'pt'
    }
  })
  this.registra()
  this.appPhonon = phonon.navigator()
  setupHTML()

  this.appPhonon.start()

 
 

  O('botaoInformacoesRetorna').addEventListener('click', this.retorna.bind(this), false)
  O('botaoConfiguracoesRetorna').addEventListener('click', this.retorna.bind(this), false)
  O('botaoConfiguracoesconfirma').addEventListener('click', this.configuracoesconfirma.bind(this), false)

  

 this.resizeCanvas()
  

}

Ui.prototype.configuracoesconfirma = function () {
  
}

Ui.prototype.retorna = function (evt) {
     phonon.sidePanel('#MENU').close()
     phonon.panel('#CONFIGURACOES').close();
     phonon.panel('#INFORMACOES').close();
}
Ui.prototype.resizeCanvas = function ()
{
  let width  = window.innerWidth;
  let height = window.innerHeight; 
 PubSub.publish('resize',{width:width,height:height});
  O('legenda').innerHTML        = 'Window:  '+parseInt((width*3)/60)+' minutes';

}

// -------------------- Registra funcoes ------------------------
Ui.prototype.registra = function () {
  // inicializa
  PubSub.subscribe('initialize', function (msg, data) {
    LOG('>>Inicializa Ui')
      window.addEventListener('resize', this.resizeCanvas.bind(this), false);
      window.addEventListener('orientationChanged', this.resizeCanvas.bind(this), false);
      PubSub.publish('resize',{})

  }.bind(this))

 PubSub.subscribe('LegendaTemperatura', function (msg, informacao) {
      LOG('>>Ui > LegendaTemperatura')
      try {
          O('legendaTempSUP').innerHTML = informacao.superior+"&#8451;";
          O('legendaTempINF').innerHTML = informacao.inferior+"&#8451;";
      } catch (e) {}
  }.bind(this))

  PubSub.subscribe('resize', function (msg, informacao) {
      LOG('>>Ui > resize')
      try {
        //O('legenda').innerHTML        = 'Window:  '+parseInt((informacao.width*3)/60)+' minutes';
        //this.resizeCanvas()
      } catch (e) {}
  }.bind(this))

}
