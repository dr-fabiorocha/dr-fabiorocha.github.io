"use strict";
var usa_log_remoto="remoto"


var userInterface
var temperatura
var isCordovaApp = true




function fail(e) {
  console.dir(e);
}



function Start () {
  if (typeof(cordova) == "object") 
  {
    
    isCordovaApp = true
  }
  else isCordovaApp=false


  this.initialize()
}
Start.prototype.pre = function ()
{
  this.onDeviceReady()
}

Start.prototype.initialize = function ()
{
 
  if (isCordovaApp==true)
  {
    LOG('Usando Cordova')
    document.addEventListener('deviceready', this.pre.bind(this), false);
    document.documentElement.style.overflow = 'hidden'
  }
  else {
      this.onDeviceReady()

    }
}

Start.prototype.onDeviceReady = function ()
{
  let temperaturaINF = 22;
  let temperaturaSUP = 42;
  userInterface = new Ui(this.releaseInfo)
  temperatura   = new Temperatura('temperatura','currentTemp',temperaturaSUP,temperaturaINF);
  PubSub.publish('initialize','')
  startRede();
}

var app = new Start()
