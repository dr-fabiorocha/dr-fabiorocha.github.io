#import <sys/unistd.h>

@interface Hostname : NSObject {}

+ (NSString*) get;

@end
