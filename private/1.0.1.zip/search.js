
const kConnectState_NotStarted = 0;
const kConnectState_ChooseMedia = 1;
const kConnectState_Search = 2;
const kConnectState_Keyword = 3;
const kConnectState_RequestConnect = 4;
const kConnectState_TransWindow = 5;
const kConnectState_Connecting = 6;
const kConnectState_RequestDisonnect = 7;
const kConnectState_RequestDisonnectShowDialog = 8;


var _localstream = null;

var _displayWidth = 0;
var _displayHeight = 0;
var _displayX = 0;
var _displayY = 0;
var _pjList = null;
var _pjSearchedList = [];
var _isCloseBy = 0;
var _isEnter = false;
var _preConnectSearchPjList = null;
var _isSearchPJProcess = false;
var _connectState = kConnectState_NotStarted;
var _pendingDisplayChangeToPJ = false;
var _handleAutoUpdateTimer = null;
var _pendingDisconnect = false;

var _ipErrorTimer = null;


function setDisplayBounds(x,y,w,h) {
	_displayX = x;
	_displayY = y;
	_displayWidth = w;
	_displayHeight = h;
}


function initButtonStatus() {
    document.getElementById('updating_str').style.visibility = "hidden";
    document.getElementById('pj-ip').focus();
    updateConnectButtonState();
}


function updateConnectButtonState() {
    var bDisable = true;
    
    if (_pjList.length > 0) {
        for (var i = 0; i < _pjList.length; i++) {
            if (_pjList[i].kPJCheckKey == 1) {
                bDisable = false;
                break;
            }
        }
    }
    
    document.getElementById('captureStart').disabled = bDisable;
    if (!bDisable) {
        document.getElementById('captureStart').focus();
    }
}


function linkMirroringProjectorsInPjList(pjInfo) {
    var mirroringProjectors = pjInfo["kPJMirrorKey"];

    for (var i = 0; i < _pjList.length; i++) {
        var pj = _pjList[i];
        var index = indexOfProjectorInArray(pj, mirroringProjectors);
        var bDisable = getProjectorSelectionStatus(pj.kPJStatusKey);
        if (index == -1) {
            if (pjInfo.kPJCheckKey == 1) {
                pj.kPJSelectableKey = 0;
            } else {
                
                if (bDisable) {
                    pj.kPJSelectableKey = 0;
                } else {
                    pj.kPJSelectableKey = 1;
                }
            }
        } else {
            
            
            
            if (bDisable == false) {
                pj.kPJSelectableKey = pjInfo.kPJSelectableKey;
                pj.kPJCheckKey = pjInfo.kPJCheckKey;
            }
        }
    }
}


function updatePJListViewSelection() {
    for (var i = 0; i < _pjList.length; i++) {
        var pj = _pjList[i];
        var curRow = $('#' + i);
        var checkbox = $(curRow).find('input:checkbox').eq(0);
        
        if (pj.kPJSelectableKey == 1) {
            
            checkbox.prop('disabled', false);
            if (pj.kPJCheckKey == 1) {
                checkbox.prop('checked', true);
            } else {
                checkbox.prop('checked', false);
            }
        } else {
            
            checkbox.prop('disabled', true);
            checkbox.prop('checked', false);
        }
    }
}


function updatePJListSelectionData(pjInfo, indexInPJList) {
    var pjstatus = pjInfo["kPJStatusKey"];
    switch (pjstatus) {
        case kProj_status_using_mpc_mirror:
            
            linkMirroringProjectorsInPjList(pjInfo);
            break;
        case kProj_status_using_mpc:
            
            if (pjInfo.kPJCheckKey == 1) {
                for (var i = 0; i < _pjList.length; i++) {
                    if (i == indexInPJList) {
                        continue;
                    }
                    _pjList[i].kPJSelectableKey = 0;
                }
            } else {
                resetProjectorListSelectionState();
            }
            break;
        case kProj_status_nouse:
            
            if (getSelectedProjectorCount() == 0) {
                resetProjectorListSelectionState();
            } else if (getSelectedProjectorCount() >= 4) {
                for (var i = 0; i < _pjList.length; i++) {
                    if (_pjList[i].kPJCheckKey == 1) {
                        continue;
                    }
                    _pjList[i].kPJSelectableKey = 0;
                }
            } else {
                for (var i = 0; i < _pjList.length; i++) {
                    var otherPJ = _pjList[i];
                    if ( (i == indexInPJList)
                        || (otherPJ["kPJStatusKey"] == kProj_status_nouse)
                        ) {
                        _pjList[i].kPJSelectableKey = 1;
                        continue;
                    }
                    _pjList[i].kPJSelectableKey = 0;
                }

            }
            break;
        default:
            
            resetProjectorListSelectionState();
            break;
    }
}


function getSelectedProjectorCount() {
    var checkedPjCnt = 0;
    for (var i = 0; i < _pjList.length; i++) {
        if (_pjList[i].kPJCheckKey == 1) {
            checkedPjCnt++;
        }
    }
    
    return checkedPjCnt;
}


function getSelectedProjectorStatus() {
    var status = -1;
    for (var i = 0; i < _pjList.length; i++) {
        if (_pjList[i].kPJCheckKey == 1) {
            status = _pjList[i].kPJStatusKey;
            break;
        }
    }
    
    return status;
}


function resetProjectorListSelectionState() {
    
    for (var i = 0; i < _pjList.length; i++) {
        var projector = _pjList[i];
        var pjstatus = projector["kPJStatusKey"];
        projector.kPJSelectableKey = 0;
        projector.kPJCheckKey = 0;
       
        switch (pjstatus) {
                
            case kProj_status_nouse:
                
            case kProj_status_using_mpc:
                
            case kProj_status_using_mpc_mirror:
            {
                projector.kPJSelectableKey = 1;
            }
                break;
                
            case kProj_status_using_notinterruption:
                
            case kProj_status_using_other:
                
            case kProj_status_notfound:
                
            case kProj_status_search:
                
            case kProj_status_internal_nosupport:
                
            case kProj_status_using_np:
                
            case kProj_status_using_mpc_max:
                projector.kPJCheckKey = 0;
                break;
            default:
                break;
        }
    }
    
    updatePJListViewSelection();
}


function initContextMenu() {
    
    $.contextMenu({
                  selector: '.scrollBody',
                  events: {
                    show: function() {
                        
                        
                        if (_isSearchPJProcess) {
                            return false;
                        } else {
                            cancelAutoUpdateTimer();
                            return true;
                        }
                    },
                    hide: function(opt) {
                        
                        
                        if (_isSearchPJProcess == false) {
                            createAutoUpdateTimer();
                        }
                    }
                  },
                  callback: null,   
                  items: {
                    "clearMenu": {
                        name: chrome.i18n.getMessage("LZD_BTN_CLEAR"),
                        icon: null,
                        
                        callback: function(key, options) {
                            clearSearchList(document.getElementById('pjList'));
                        },
                        disabled: function(key, opt) {
                            return this.data('contextMenuDisabled');
                        }
                    },
                    "separator": "---------",
                    "updateMenu": {
                        name: chrome.i18n.getMessage("LZD_BTN_UPDATE"),
                        icon: null,
                        
                        callback: function(key, options) {
                            updateSearchList();
                        },
                        disabled: function(key, opt) {
                            return this.data('contextMenuDisabled');
                        }
                    },
                  }
    });
    $('tbody.scrollBody').data('contextMenuDisabled', false);
}


function getDisplayInfo() {
  chrome.system.display.getInfo(function(displayInfo) {
    var info = displayInfo[0];
    _displayWidth = info.bounds.width;
    _displayHeight = info.bounds.height;
    _displayX = info.bounds.left;
    _displayY = info.bounds.top;


  });

}


function loadSearchedProjectorList() {
	chrome.runtime.getBackgroundPage(function(bg) {
		_pjSearchedList = bg._syncSettings.SearchList.concat();
		updateProjectorSearchedList(false);
    });
}


function clearSearchedProjectorList() {
    _pjSearchedList.splice(0, _pjSearchedList.length);
    updateProjectorSearchedList(false);
}


function updateProjectorSearchedList(isNeedSelect) {
    var pj_search_list = document.getElementById('pj-search-list');
    html = '';
    for (var i = 0; i < _pjSearchedList.length; i++) {
        var dic = _pjSearchedList[i];
         html += '<option value="' + i + '">' +dic.ip + ' ' + dic.name + '</option>';
    }
    pj_search_list.innerHTML = html;
    if (isNeedSelect == true) {
        pj_search_list.value = 0;
    } else {
        pj_search_list.selectedIndex = -1;
    }
}


function clearSearchList(table) {
    if ( $('tbody.scrollBody').data('contextMenuDisabled') == false){
        if (_pjList.length > 0) {
            logMsg("call clearSearchList");
            
            
            while( table.rows[ 1 ] ) table.deleteRow( 1 );  
            
            var key = "clear_menu";
            PostMessage(kCmdSearchListAction, key, "");
            
            _pjList.length = 0;
            
            updateConnectButtonState();
        }
    }
}


function updateSearchList() {
    if ( $('tbody.scrollBody').data('contextMenuDisabled') == false){
        if (_pjList.length > 0) {
            logMsg("call updateSearchList");

            _isSearchPJProcess = true;
            
            
            
            
            disableSearchControls();
            
            document.getElementById('updating_str').style.visibility = "visible";
            
            
            var key = "update_menu";
            var updatePJList = _pjList.concat();
            PostMessage(kCmdSearchListAction, key, updatePJList);
        }
    }
}


function attachListeners() {
	document.getElementById('minimize').addEventListener('click', doMinimize);
	document.getElementById('close').addEventListener('click', doClose);

    document.getElementById('captureStart').addEventListener('click', doStart);
    document.getElementById('pjList').addEventListener('change', doPJListChanged);
    document.getElementById('searchStart').addEventListener('click', doSearchStart);
    document.getElementById('pj-search-list').addEventListener('focus', onPrepareSelectProjector);
    document.getElementById('pj-search-list').addEventListener('change', onSelectProjector);
    document.getElementById('pj-ip').addEventListener('keyup', doKeyUpNumOnly);
    document.getElementById('pj-ip').addEventListener('keydown', doKeyDownNumOnly);
    document.getElementById('pj-ip').addEventListener('paste', handlePasteData);
    document.getElementById('pj-ip').addEventListener('drop', handleDropData);
    document.getElementById('showoptionwindow').addEventListener('click', doOption);
    document.getElementById('showsupportwindow').addEventListener('click', doSupportWindow);
    window.addEventListener("online", onOnOffLine, false);
    window.addEventListener("offline", onOnOffLine, false);
    window.addEventListener("keyup", doKeyUp);
    
    $('tbody.scrollBody').on('scroll', doScrollPJListView);
    
    loadSearchedProjectorList();
    getDisplayInfo();
}


function getTimeInMilliseconds() {
  return (new Date()).getTime();
}



function doSearchStart(event) {
	logMsg("call doSearchStart!!");

	
	if (null != _handleAutoUpdateTimer) {
		cancelAutoUpdateTimer();
	}

	var pjip = document.getElementById('pj-ip');
	var pj_ip = pjip.value;
	pj_ip = strimIPAddress(pj_ip);

	if (checkValidIPAddress(pj_ip)) {
		
		if (pjip.value.length > 0) {  
			document.getElementById('pj-ip').value = pj_ip;
		}

		clearAndPushToList(pj_ip);

		var key = "dstaddr";


		var dict = new Array({key: "frame_X", value: _displayX},
			{key: "frame_Y", value: _displayY},
			{key: "frame_width", value: _displayWidth},
			{key: "frame_height", value: _displayHeight});

		PostMessage(kCmdInitParams, key, dict);

		var projector = new Object();
		projector.kPJIPAddressKey = pj_ip;

		var row = -1; 
		for (var i = 0; i < _pjList.length; i++) {
			if (pj_ip == _pjList[i].kPJIPAddressKey) {
				projector = _pjList[i];
				row = i; 
				break;
			}
		}
		
		for (var i = 0; i < _preConnectSearchPjList.length; i++) {
			if (pj_ip == _preConnectSearchPjList[i].kPJIPAddressKey) {
				projector = _preConnectSearchPjList[i];
				break;
			}
		}

		
		var key2 = "dstaddr";
		var dict2 = new Array(projector);

		PostMessage(kCmdSearchStart, key2, dict2);

		_isSearchPJProcess = true;

		
		if (row >= 0) {
			var curRow = $('#' + row);
			var tableRow = $(curRow).closest('tr').index();
			
			if (tableRow > 0) {
				var elementsStr = $(curRow);
				$('tbody.scrollBody tr').eq(tableRow).remove();
				$('tbody.scrollBody tr:first').before(elementsStr);
			}
			
			
			var bCheckForNewPJ = false;
			var pjstatus = _pjList[row].kPJStatusKey;
			if ( (pjstatus == kProj_status_nouse) 
					|| (pjstatus == kProj_status_using_mpc)   
					|| (pjstatus == kProj_status_using_mpc_mirror)    
				) {
				bCheckForNewPJ = true;
			}
			if (bCheckForNewPJ) {
				resetProjectorListSelectionState();
				_pjList[row].kPJCheckKey = 1;
				updatePJListSelectionData(_pjList[row], row);
				
				updatePJListViewSelection();
				
				
			}
            
            _pjList[row].bChenckAfterFound = 1;
		}
		
		
		$('tbody.scrollBody').scrollTop(0);

		
		
		
		
		disableSearchControls();
	} else {
		showDialogOnCurrentWindow(LZD_ERR_STR_INVALID_IP_ADDRESS, function () {
			if (_isEnter) {
				_isCloseBy = 2;
				_isEnter = false;
			} else {
				_isCloseBy = 1;
			}
			selecteAllText();
		}, null);
		updateProjectorSearchedList(false);
	}
}


function doSearchStop(event) {
    logMsg("call doSearchStop!!");
    
	PostMessage(kCmdSearchStop, "", "");
}


function doOption(event) {
    logMsg("call doOption!!");
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg.showOptionWindow == 'undefined') {
			return;
		}
		bg.showOptionWindow();
	});
}


function doSupportWindow(event) {
	logMsg("call doSupportWindow!!");
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg.showSupportWindow == 'undefined') {
			return;
		}
		bg.showSupportWindow();
	});
}


function indexOfProjectorInArray(aProjector, array) {
    var indexOfProjector = -1;
    
    for (var i = 0; i < array.length; i++) {
        var projectorInArray = array[i];
        if (
            (projectorInArray.kPJNameKey == aProjector.kPJNameKey)
            && (projectorInArray.kPJIPAddressKey == aProjector.kPJIPAddressKey)
            ) {
            indexOfProjector = i;
            break;
        }
    }
    
    return indexOfProjector;
}


function indexOfProjectorInArrayUseIpAddress(aProjector, array) {
    var indexOfProjector = -1;
    
    for (var i = 0; i < array.length; i++) {
        var projectorInArray = array[i];
        if ( (projectorInArray.kPJIPAddressKey == aProjector.kPJIPAddressKey)
            ) {
            indexOfProjector = i;
            break;
        }
    }
    
    return indexOfProjector;
}


function connectProcess0() {
	logMsg("call connectProcess0");
	
	
	_connectState = kConnectState_ChooseMedia;
	
	
	cancelAutoUpdateTimer();
	
	
	disableSearchControls();
	
	
	chrome.desktopCapture.chooseDesktopMedia( ["screen"], onAccessApproved);
}


function connectProcess1() {
	logMsg("call connectProcess1");
	
	_connectState = kConnectState_Search;
	
	
	showConnecting();
	
	
	var key = "connect_check";
	var array = new Array();
    var pjListArray = _pjList.concat();
	
	var row=0;
	for(row=0; row < _pjList.length; row++){
		var pjInfo = _pjList[row];
		
		
		pjInfo.kPJKeywordStringKey = null;
		
		
		if(pjInfo.kPJCheckKey == 1) {
			array.push(pjInfo);
			logMsg("connect:row=" + row + ", pjid=" + pjInfo.kPJIDKey);
		}
	}
    
    
    
    
    var dictionary = {"connectPjList":array, "pjList":pjListArray};
	PostMessage(kCmdCaptureStart, key, dictionary);
	
	
	_preConnectSearchPjList.length = 0;
	
	chrome.runtime.getBackgroundPage(function(bg){
		
		bg.setConnectedPJList(null);
	});
}


function connectProcess2() {
	logMsg("call connectProcess2");
	
	_connectState = kConnectState_Keyword;
	
	
	var readyToNextProcess = true;
	
	var row=0;
	var pjInfo = null;
	for(row=0; row < _pjList.length; row++){
		pjInfo = _pjList[row];
		if(pjInfo.kPJCheckKey == 1) {
			if(pjInfo.kPJKeywordKey == 1) {
				if(pjInfo.kPJKeywordStringKey == null) {
					
					
					showKeyword(pjInfo.kPJRetryTimes, pjInfo, connectProcess2, connectCancel);
					readyToNextProcess = false;
					break;
				}
			}
		}
	}
	
	if (readyToNextProcess == true) {
		
		var preConnectSearcPJ = null;
		for(row = 0; row < _preConnectSearchPjList.length; row++) {
			preConnectSearcPJ = _preConnectSearchPjList[row];
			if (preConnectSearcPJ.kPJKeywordKey == 1) {
				
				var index = indexOfProjectorInArray(preConnectSearcPJ, _pjList);
				if (index != -1) {
					pjInfo = _pjList[index];
					preConnectSearcPJ.kPJKeywordStringKey = pjInfo.kPJKeywordStringKey;
				}
				
				
				
				if (preConnectSearcPJ.kPJKeywordStringKey == null) {
					showKeyword(preConnectSearcPJ.kPJRetryTimes, preConnectSearcPJ, connectProcess2, connectCancel);
					readyToNextProcess = false;
					break;
				}
			}
		}
	}
	
	
	if (readyToNextProcess == true) {
		connectProcess3();
	}
}


function connectProcess3() {
	logMsg("call connectProcess3");
	
	
	var key = "connect";
	var array = new Array();
	
	
	
	
	
	if (_pendingDisconnect) {
		requestDisconnect();
		_pendingDisconnect = false;
		return;
	}
	
	
	var row=0;
	for(row=0; row < _pjList.length; row++){
		var pjInfo = _pjList[row];
		if(pjInfo.kPJCheckKey == 1) {
			array.push(pjInfo);
		}
	}
	
	
	
	for (var i = 0; i < _preConnectSearchPjList.length; i++) {
		var bSamePJInArray = false;
		var preConnectSearcPJ = _preConnectSearchPjList[i];
		for (var j = 0; j < array.length; j++) {
			if (
				(preConnectSearcPJ.kPJNameKey == array[j].kPJNameKey)
				&& (preConnectSearcPJ.kPJIPAddressKey == array[j].kPJIPAddressKey)
				) {
				bSamePJInArray = true;
				break;
			}
		}
		if (bSamePJInArray == false) {
			_preConnectSearchPjList[i].kPjAddPreConnectSearchPJ = 1;
			array.push(preConnectSearcPJ);
		}
	}
	
	chrome.runtime.getBackgroundPage(function(bg){
		
		
		sendCaptureStream(_localstream);
		
		
		var usrname = bg._syncSettings.UserName;
		PostMessage(kCmdSetUserName, "UserName", usrname);
		
		
		var cli_multihigh = true;
		PostMessage(kCmdCliMultiHigh, "cli_multihigh", cli_multihigh);
		
		
		var cli_network = (bg._syncSettings.LowerResolution == kOptionLowerResolutionOff) ? false : true;
		PostMessage(kCmdCliNetwork, "cli_network", cli_network);
		
		
		var bandControl = bg._syncSettings.Band;
		PostMessage(kCmdBandControl, "band_control", Number(bandControl));
		
		
        
        
        
        var dictionary = {"connectPjList":array};
		PostMessage(kCmdCaptureStart, key, dictionary);
		
		
		_connectState = kConnectState_RequestConnect;
		
		
		bg.setConnectedPJList(array);
	});
}


function connectProcess4() {
	logMsg("call connectProcess4");
    if ( (_connectState == kConnectState_RequestDisonnectShowDialog)
        || (_connectState < kConnectState_RequestConnect)
          ) {
        return;
    }
	
	
	_connectState = kConnectState_TransWindow;
	
	
	hideConnecting();
		
	chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
		
		if (backgroundPage.hideSearchWindow) {
			backgroundPage.hideSearchWindow();
		}
		
		
		if (backgroundPage.showToolbarWindow === 'undefined') {
			return;
		}
		
		backgroundPage.showToolbarWindow(true);
		
		
		
		setTimeout(function () {
			_connectState = kConnectState_Connecting;
			
			
			if (_pendingDisconnect) {
				logMsg("need disconnect.");
				requestDisconnect();
				_pendingDisconnect = false;
			} else {
				
				if (true == _pendingDisplayChangeToPJ) {
					logMsg("--- DisplayChange to PJ (Pending)");
					chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
						if (backgroundPage.onDisplayChanged) {
							backgroundPage.onDisplayChanged();
						}
					});
					_pendingDisplayChangeToPJ = false;
					logMsg("--- _pendingDisplayChangeToPJ = false;");
				}
			}
		}, 500);
	});
}


function connectCancel() {
	logMsg("call connectCancel");

	
	removePreConnectSearchPJFromPJController();
		
	
	if (_connectState >= kConnectState_Search) {
		hideConnecting();
	}

	
	if (_localstream) {
		_localstream.getVideoTracks()[0].stop();
		_localstream = null;
	}
	
	
	enableSearchControls();
	
    
    
    updateSearchList();
    
    
    _connectState = kConnectState_NotStarted;
    
	chrome.runtime.getBackgroundPage(function(bg){
		
		bg.setConnectedPJList(null);
	});
}


function chooseMediaCancel() {
    logMsg("call chooseMediaCancel");

    
    enableSearchControls();
    
    
    createAutoUpdateTimer();
    
    
    _connectState = kConnectState_NotStarted;
}


function requestDisconnect() {
	logMsg("call requestDisconnect");
	
	logMsg("_connectState:" + _connectState);
	if (_connectState >= kConnectState_Connecting) {
		
		PostMessage(kCmdCaptureCancel, "", "");
		_connectState = kConnectState_RequestDisonnect;
	} else 	if (_connectState >= kConnectState_RequestConnect) {
		
		_pendingDisconnect = true;
    } else if (_connectState == kConnectState_Keyword) {
        
        
        $( "#keyword-dialog" ).dialog('close');
    } else if (_connectState >= kConnectState_Search) {
        connectCancel();
	} else if (_connectState == kConnectState_ChooseMedia) {
		
		
        chooseMediaCancel();
	}
}


function doMinimize(event) {
	logMsg("call doMinimize!!");

	
	document.getElementById('minimize').style.display = 'none';

	
	chrome.runtime.getBackgroundPage(function(bg) {
		bg.minimizeSearchWindow();
	});
}


function doClose(event) {
	logMsg("call doClose!!");
	
	
	chrome.runtime.getBackgroundPage(function(bg) {
		bg.closeSearchWindow();
	});
}


function doStart(event) {
	logMsg("call doStart!!");

	connectProcess0();
}


function doPJListChanged(event) {
  logMsg("call doPJListChanged!!");
	
	
	
	var row = $(event.target).closest("tr").index();
	var curRow = $(event.target).closest("tr");
	var index = Number(curRow[0].id);
	var pjcheck = $(curRow).find('input:checkbox').eq(0);
	if (pjcheck.prop('checked')) {
        _pjList[index].kPJCheckKey = 1;
	} else {
		pjcheck.prop('checked', true);
        _pjList[index].kPJCheckKey = 0;
	}
    
    updatePJListSelectionData(_pjList[index], index);
    
    updatePJListViewSelection();

    updateConnectButtonState();
    
	logMsg("listchange:row=" + row + " val=" + _pjList[index].kPJCheckKey);
}


function onPrepareSelectProjector(event) {
	
	
	
	document.getElementById('pj-search-list').value = -1;
}


function onSelectProjector(event) {
    var selected = document.getElementById('pj-search-list').value;
    var dict = _pjSearchedList[selected];
    document.getElementById('pj-ip').value = dict.ip;
    doSearchStart(event);
}


function doKeyUpNumOnly(event) {
    if (event.keyCode == 13) { 
        if (_isCloseBy == 2) { 
            _isCloseBy = 0;
        } else {
          _isCloseBy = 0;
          doSearchStart();
        }
    }
}


function showIPError() {
	document.getElementById('ipaddress_error').style.opacity = 1;
	clearTimeout(_ipErrorTimer);
	_ipErrorTimer = setTimeout(hideIPError, 5000);
}
	

function hideIPError() {
	document.getElementById('ipaddress_error').style.opacity = 0;
	clearTimeout(_ipErrorTimer);
	_ipErrorTimer = null;
}


function doKeyDownNumOnly(event) {
    
    
    
    var bCtrlKey = false;
    if (window.navigator.platform.match(/MacIntel/)) {
        bCtrlKey = event.metaKey;
        
        if (event.keyCode == 81 && (bCtrlKey === true)) {
			hideIPError();
			return;
        }
    } else {
        bCtrlKey = event.ctrlKey;
    }
    if (
        (($.inArray(event.keyCode, [46, 8, 9, 27, 13, 37, 39, 190]) !== -1)
          && (event.shiftKey === false)) ||
        
        (event.keyCode == 65 && (bCtrlKey === true)) ||
        
        (event.keyCode == 67 && (bCtrlKey === true)) ||
        
        (event.keyCode == 88 && (bCtrlKey === true)) ||
        
        (event.keyCode == 86 && (bCtrlKey === true)) ||
        
        (event.keyCode == 87 && (bCtrlKey === true)) ||
		
		(event.keyCode == 244) ||
		
		(event.keyCode == 28) ||
		
		(event.keyCode == 29) ||
		
		(bCtrlKey === true)) {
		hideIPError();
        return;
    }
    
    
    var c = String.fromCharCode(event.keyCode);
	if ("0123456789".indexOf(c, 0) < 0 || event.shiftKey) {
		event.preventDefault();
		showIPError();
	} else {
		hideIPError();
	}
}


function doKeyUp(event) {
    if (event.keyCode == 13) {
        _isEnter = true;
    }
}


function handlePasteData(event) { 
    logMsg("OnPaste");
    var savedcontent = "";
    if (event && event.clipboardData && event.clipboardData.getData) { 
        
        var pasteData;
        if(event.clipboardData.types.indexOf('text/plain') > -1){
            pasteData = event.clipboardData.getData('text/plain');
        }
        else {
            pasteData = "";
        }
        var value = document.getElementById('pj-ip').value;
		var replacedData = pasteData.replace(/[^(0-9.)]/g,"");
		if (replacedData != pasteData) {
			pasteData = replacedData;
			showIPError();
		}
        var pos = document.getElementById('pj-ip').selectionStart;
        var end = document.getElementById('pj-ip').selectionEnd;
        var length1 = document.getElementById('pj-ip').value.length;
        var length = pasteData.length;
        if (pasteData.length + value.length + pos - end > 15) pasteData = pasteData.substr(0, 15 - length1 + end - pos);
        
        
        document.getElementById('pj-ip').value =  value.substr(0, pos) + pasteData + value.substr(end);
        length = pasteData.length;
        document.getElementById('pj-ip').selectionStart = pos + length;
        document.getElementById('pj-ip').selectionEnd = pos + length;
        
        
        event.preventDefault();
        return false;
    } else { 
		hideIPError();
        return true;
    }
}


function handleDropData(event) {
	logMsg("Drop event");

	
	event.preventDefault();
	return false;
}


function strimIPAddress(ip) {
    var result = "";
    var array = ip.split(".");
    for (var i = 0; i < array.length; i++) {
        if (array[i]== "") array[i] = "0"; 
        var val = parseInt(array[i]);
        if (isNaN(val)) {
            return ip;
        } else {
            result += val;
        }
        if (i < array.length - 1) result += ".";
    }
    
    
    if (result.length > 15) {
        result = ip;
    }
    return result;
}



function checkValidIPAddress(ip) {
    var result = true;
    var array = ip.split(".");
    if (array.length != 4) result = false;
    var countBy0 = 0;
    var countBy255 = 0;
    for (var i = 0; i < array.length; i++) {
        var val = parseInt(array[i]);
        if (val > 255 || val < 0 || isNaN(val)) {
            result = false;
            break;
        }
        if (val == 0) countBy0 += 1;
        if (val == 255) countBy255 += 1;
    }
    if (countBy0 == 4 || countBy255 == 4) result = false;
    return result;
    
}


function clearAndPushToList(data) {
	
    for (var i = 0; i < _pjSearchedList.length; i++) {
        if (_pjSearchedList[i].ip == data) {
            _pjSearchedList.splice(i, 1);
            break;
        }
    }
	
    if (_pjSearchedList.length >= 10) {
        _pjSearchedList.splice(9);
	}
	
	
    var dict = new Object();
    dict.ip = data; dict.name = "";
    _pjSearchedList.unshift(dict);	

	
    chrome.runtime.getBackgroundPage(function(bg) {
        for (var i = 0; i < bg._syncSettings.SearchList.length; i++) {
            if (bg._syncSettings.SearchList[i].ip == data) {
                bg._syncSettings.SearchList.splice(i, 1);
                break;
            }
        }
        if (bg._syncSettings.SearchList.length >= 10) {
            bg._syncSettings.SearchList.splice(9);
        }
        var dict2 = new Object();
        dict2.ip = data; dict2.name = "";
        bg._syncSettings.SearchList.unshift(dict2);	
    });
}


function updateProjectorSearchedListInfo() {
    for (var i = 0; i < _pjSearchedList.length; i++) {
        var pj = _pjSearchedList[i];
        for (var j = 0; j < _pjList.length; j++) {
            if (pj.ip == _pjList[j].kPJIPAddressKey && pj.name != _pjList[j].kPJNameKey) {
                pj.name = _pjList[j].kPJNameKey;
                break;
            }
        }
    }
	
	chrome.runtime.getBackgroundPage(function(bg) {
		for (var i = 0; i < bg._syncSettings.SearchList.length; i++) {
			for (var j = 0; j < _pjList.length; j++) {
				if (bg._syncSettings.SearchList[i].ip == _pjList[j].kPJIPAddressKey &&
					bg._syncSettings.SearchList[i].name != _pjList[j].kPJNameKey) {
					bg._syncSettings.SearchList[i].name = _pjList[j].kPJNameKey;
					break;
				}
			}
		}
	});
	
    updateProjectorSearchedList(true);
    selecteAllText();
}


function selecteAllText() {
    
    var active_element = document.activeElement;
    if (active_element.tabIndex == -1) {
        document.getElementById('pj-ip').focus();
        document.getElementById('pj-ip').select();
    }
}


function doScrollPJListView(e) {
    
    if (e.currentTarget.scrollLeft > 0) {
        e.currentTarget.scrollLeft = 0;
    }
}


function onDisplayChanged(displayRotationOld, displayRotationNew) {
	logMsg("Display Changed - search");

	
	chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
		if (backgroundPage.initSearchWindow) {
			backgroundPage.initSearchWindow(document);
		}
	});

	
	if (displayRotationOld != displayRotationNew) {
		logMsg("Display Rotation Changed frome "+ displayRotationOld +"℃ to "+ displayRotationNew +"℃");

		var active_element = document.activeElement;

		
		if ( (active_element.id == "pj-ip")
		||   (active_element.id == "kw-pjkeyword")
		) {
			active_element.blur();

			
			setTimeout(function () {
				active_element.focus();
			}, 500 );
		}
	}

}






function isEnabledDisplayChangeToPJ(){

	var flg = 0;

	switch (_connectState) {
	case kConnectState_NotStarted:			
	case kConnectState_ChooseMedia:			
	case kConnectState_Connecting:			
		flg = 0;
		break;
	case kConnectState_Search:				
	case kConnectState_Keyword:				
	case kConnectState_RequestConnect:		
	case kConnectState_TransWindow:			
		flg = 1;
		break;
	case kConnectState_RequestDisonnect:	
	default:
		flg = 1;	
		break;
	}

	logMsg("--- isEnabledDisplayChangeToPJ() : " + flg );
	return flg;
}



function setPendingDisplayChangeToPJ(flg){
	_pendingDisplayChangeToPJ = flg;
	logMsg("--- setPendingDisplayChangeToPJ(" + flg + ")" );
}



function onOnOffLine(){
	PostMessage(kCmdNicList, "key", "val");
}


function handleSearchPJ(val) {
	var pjInfo = val["pjinfo"];
	var pjid = pjInfo["kPJIDKey"];
	var pjstatus = pjInfo["kPJStatusKey"];
	var pjname = pjInfo["kPJNameKey"];
	var pjip = pjInfo["kPJIPAddressKey"];
	var pjuniq = pjInfo["kPJUniqInfoKey"];
	var pjkeyword = pjInfo["kPJKeywordKey"];
	var pjkeywordstring = pjInfo["kPJKeywordStringKey"];
	var pjdata = pjInfo["kPJDataKey"];
	var pjmirrors = pjInfo["kPJMirrorKey"];
	var exist = false;
	var row=1;

    
    if (_connectState == kConnectState_Search) {
        for (var i = 0; i < _preConnectSearchPjList.length; i++) {
            var projector = _preConnectSearchPjList[i];
            if (projector[kPJNameKey] == pjname && projector[kPJIPAddressKey] == pjip) {
                _preConnectSearchPjList[i] = pjInfo;
                var bDisable = getProjectorSelectionStatus(pjstatus);
                if ( bDisable == false ) {   
                    _preConnectSearchPjList[i].bSearchedFlag = 1;
                }
            }
        }
    }
    else {
        
        for (row=0; row < _pjList.length; row++) {
            var idvalue = _pjList[row].kPJIDKey;
            if (idvalue == pjInfo["kPJIDKey"]) {
                var pjCheck = _pjList[row].kPJCheckKey;         
                var pjSelect = _pjList[row].kPJSelectableKey;   
                    
                
                var bDisableAfter = getProjectorSelectionStatus(pjstatus);
                var bDisableBefore = getProjectorSelectionStatus(_pjList[row].kPJStatusKey);
                      
                var bCheckForNewPJ = false;
                
                if ( (_pjList[row].kPJStatusKey == kProj_status_search) 
                    && ( (pjstatus == kProj_status_nouse) 
                        || (pjstatus == kProj_status_using_mpc)   
                        || (pjstatus == kProj_status_using_mpc_mirror)    
                        )
                    ) {
                    bCheckForNewPJ = true;
                }
                if (_pjList[row].bChenckAfterFound == 1) {
                    if( (pjstatus == kProj_status_nouse) 
                        || (pjstatus == kProj_status_using_mpc)   
                        || (pjstatus == kProj_status_using_mpc_mirror)    
                       ) {
                        bCheckForNewPJ = true;
                    }
                    
                    _pjList[row].bChenckAfterFound = 0;
                }

                
                mergeObjectValue(_pjList[row], pjInfo);    
                _pjList[row].kPJCheckKey = 0;
                _pjList[row].kPJSelectableKey = 0;

                if (bDisableBefore == true && bDisableAfter == true) {  
                          
                } else if (bDisableBefore == true && bDisableAfter == false) {  
                    
                    if (bCheckForNewPJ) {
                        resetProjectorListSelectionState();
                        _pjList[row].kPJCheckKey = 1;
                        updatePJListSelectionData(_pjList[row], row);
                    } else {
                        
                        
                        pjSelect = getProjectorSelectable(_pjList[row], pjstatus);
                        _pjList[row].kPJSelectableKey = pjSelect;
                              
                        if (pjstatus == kProj_status_using_mpc_mirror) {
                            linkMirroringProjectorsInPjList(_pjList[row]);
                        }
                    }
                } else if (bDisableBefore == false && bDisableAfter == true) {  
                    
                    _pjList[row].kPJCheckKey = 0;
                    _pjList[row].kPJSelectableKey = 0;
                    
                    
                    if (getSelectedProjectorCount() == 0) {
                        resetProjectorListSelectionState();
                    }
                } else {  
                    
                    
                    pjSelect = getProjectorSelectable(_pjList[row], pjstatus);
                    _pjList[row].kPJSelectableKey = pjSelect;
                          
                    if (pjSelect == false) {  
                        _pjList[row].kPJCheckKey = 0;
                    } else {  
                        _pjList[row].kPJCheckKey = pjCheck;       
                              
                        if (pjstatus == kProj_status_using_mpc_mirror) {
                            linkMirroringProjectorsInPjList(_pjList[row]);
                        } else {
                            updatePJListSelectionData(_pjList[row], row);
                        }
                    }
                }

                
                
                disablePJListViewCheckbox();

                exist = true;
                break;
            }
        }

        var pjStatusStr = getStatusNumName(pjstatus);
        var pjstatusIcon = getStatusNumImage(pjstatus);
    
        
        if (exist == false) {
            _pjList.push(pjInfo);
            _pjList[row].kPJCheckKey = 0;
            _pjList[row].kPJSelectableKey = 0;
            _pjList[row].bChenckAfterFound = 0;
			var elementsStr =	'<tr id=\"' + row + '\" class="pjtr">' +
								'<td class="ckbtd"><input tabindex="-1" type="checkbox"/></td>' +
								'<td class="icontd"></td>' +
								'<td class="statustd"></td>' +
								'<td class="nametd"></td>' +
								'<td class="iptd"></td>' +
								'</tr>';
            if (_pjList.length == 1) {
				
                $('#pjList').append(elementsStr);
            } else {
				
                $('tbody.scrollBody tr:first').before(elementsStr);
            }
            
            
			var curRow = $('#' + row);
            var checkbox = $(curRow).find('input:checkbox').eq(0);
			checkbox.prop('checked', false);
            checkbox.prop('disabled', true);
            
            
            
            var bDisable = getProjectorSelectionStatus(pjstatus);
            if (bDisable == false) {
                resetProjectorListSelectionState();
                _pjList[row].kPJCheckKey = 1;
                updatePJListSelectionData(_pjList[row], row);

                if (pjstatus == kProj_status_using_mpc_mirror) {
                    linkMirroringProjectorsInPjList(_pjList[row]);
                }
                
                updatePJListViewSelection();
            }
        }

		
		var mirrorPjStr = "";
		if (pjstatus === kProj_status_using_mpc_mirror) {
			for (var index = 0; index < pjmirrors.length; index++) {
				if (mirrorPjStr.length > 0) {
					mirrorPjStr += "\n";
				}
				mirrorPjStr += " ";
				mirrorPjStr += pjmirrors[index].kPJNameKey;
				mirrorPjStr += "\t";
				mirrorPjStr += pjmirrors[index].kPJIPAddressKey;
			}
		}
	
		var currentRow = $('#' + row);
        
		var iconCell = $(currentRow).find('.icontd');
		if (pjstatusIcon) {
			iconCell[0].innerHTML = '<img src=\"' + pjstatusIcon + '\"  class="pjicon" height="25">';
		}
		iconCell[0].title = pjStatusStr;
	
        
		var statusCell = $(currentRow).find('.statustd');
		statusCell.text(pjStatusStr);
		statusCell[0].title = pjStatusStr;
	
        
		var pjnameCell = $(currentRow).find('.nametd');
		pjnameCell.text(pjname);
		if (pjstatus === kProj_status_using_mpc_mirror) {
			pjnameCell[0].title = pjname + "\n" + mirrorPjStr;
		} else {
			pjnameCell[0].title = pjname;
		}
	
        
		var ipCell = $(currentRow).find('.iptd');
		ipCell.text(pjip);
		ipCell[0].title = pjip;
    }
}


function mergeObjectValue(targetObj, newObj) {
    for(var key in newObj){
        targetObj[key] = newObj[key];
    }
}


function getProjectorSelectable(pjInfo, inStatus) {
    var bSelectable = false;
    
    var selectedPJCnt = getSelectedProjectorCount();
    switch (inStatus) {
        case kProj_status_nouse:    
            if (selectedPJCnt == 0) {   
                bSelectable = true;
            } else {
                var selectedPJStatus = getSelectedProjectorStatus();
                if ( (selectedPJStatus == kProj_status_nouse)   
                    && (selectedPJCnt < 4)
                    ) {
                    bSelectable = true;
                } else {    
                    
                }
            }
            break;
        case kProj_status_using_mpc:    
            if (selectedPJCnt == 0) {   
                bSelectable = true;
            } else {    
                
            }
            break;
        case kProj_status_using_mpc_mirror: 
            if (selectedPJCnt == 0) {   
                bSelectable = true;
            } else {    
                var selectedPJStatus = getSelectedProjectorStatus();
                if (selectedPJStatus == kProj_status_using_mpc_mirror) {    
                    
                    var indexInPjList = -1;
                    for (var i = 0; i < _pjList.length; i++) {
                        var pj = _pjList[i];
                        if (pj.kPJCheckKey == 1) {
                            indexInPjList = i;
                            break;
                        }
                    }
                    var mirroringPj = _pjList[indexInPjList];   
                    var index = indexOfProjectorInArray(pjInfo, mirroringPj["kPJMirrorKey"]);
                    if (index >= 0) {   
                        bSelectable = true;
                    } else {    
                        
                    }
                } else {    
                    
                }
            }
            break;
        
        default:
            break;
    }
    
    return bSelectable;
}


function getProjectorSelectionStatus(inStatus) {
    var bDisable = true;
    
    switch (inStatus) {
            
        case kProj_status_nouse:
            
        case kProj_status_using_mpc:
            
        case kProj_status_using_mpc_mirror:
            bDisable = false;
            break;
            
        case kProj_status_using_notinterruption:
            
        case kProj_status_using_other:
            
        case kProj_status_notfound:
            
        case kProj_status_search:
            
        case kProj_status_internal_nosupport:
            
        case kProj_status_using_np:
            
        case kProj_status_using_mpc_max:
        default:
            break;
    }
    
    return bDisable;
}


function getStatusNumName(inStatus) {
    var name = null;
    
    switch (inStatus)
    {
            
        case kProj_status_nouse:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_WAITING");
            break;
            
        case kProj_status_using_notinterruption:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_USED");
            break;
            
        case kProj_status_using_other:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_USED");
            break;
            
        case kProj_status_using_mpc:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_BUSY_DISABLE_INTERRUPT");
            break;
            
        case kProj_status_notfound:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_NON_DETECTION");
            break;
            
        case kProj_status_search:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_IN_SEARCHING");
            break;
            
        case kProj_status_internal_nosupport:
            name = chrome.i18n.getMessage("LZD_QSTN_UNSUPPORT_PROJECTOR");
            break;
            
        case kProj_status_using_mpc_mirror:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_MIRRORING");
            break;
            
        case kProj_status_using_np:
            name = chrome.i18n.getMessage("LZD_PRJ_STATUS_USED");
            break;
            
        case kProj_status_using_mpc_max:
        default:
            name = "--";
            break;
    }
    
    return name;
}


function getStatusNumImage(inStatus) {
    var imgPath = null;
    
    switch (inStatus)
    {
            
        case kProj_status_nouse:
            imgPath = "images/PJ_waiting.png";
            break;
            
        case kProj_status_using_notinterruption:
            imgPath = "images/PJ_Mirroring.png";
            break;
            
        case kProj_status_using_other:
            imgPath = "images/PJ_Mirroring.png";
            break;
            
        case kProj_status_using_mpc:
            imgPath = "images/PJ_user.png";
            break;
            
        case kProj_status_notfound:
            imgPath = "images/PJ_help.png";
            break;
            
        case kProj_status_search:
            imgPath = "images/PJ_search.png";
            break;
            
        case kProj_status_internal_nosupport:
            imgPath = "images/PJ-search-stop.png";
            break;
            
        case kProj_status_using_mpc_mirror:
            imgPath = "images/PJ_link.png";
            break;
            
        case kProj_status_using_np:
            imgPath = "images/PJ_user.png";
            break;
            
        case kProj_status_using_mpc_max:
        default:
            break;
    }
    
    return imgPath;
}


function handleSearchEnd() {
  logMsg("call handleSearchEnd.");
  
    if (_connectState == kConnectState_Search) {
        var error = kErrorCheckSuccess;
        for (var i = 0; i < _preConnectSearchPjList.length; i++) {
            if (_preConnectSearchPjList[i].bSearchedFlag == 1) {
                continue;
            } else {
                error = kErrorPreConnectSearch;
                break;
            }
        }
        
        var detail = {"kPJIDKey":-1, "kPJErrorKey":0};
        handleConnectionError(error, detail);
    } else {
        
        for (var i = 0; i < _pjList.length; i++) {
            var samePJIndexList = getSameIpProjectorInPJList(_pjList[i].kPJIPAddressKey);
            if (samePJIndexList.length > 1) {
                removeSameProjectorInList(samePJIndexList);
            }
        }

        
        createAutoUpdateTimer();
        
        
        
        
        enableSearchControls();
        
        document.getElementById('updating_str').style.visibility = "hidden";
        updateProjectorSearchedListInfo();
        
        _isSearchPJProcess = false;
    }
}


function getSameIpProjectorInPJList(in_ip) {
    var samePJIndexList = new Array();
    
    
    for (var i = 0; i < _pjList.length; i++) {
        if (_pjList[i].kPJIPAddressKey == in_ip) {
            samePJIndexList.push(i);
        }
    }
    
    return samePJIndexList;
}


function removeSameProjectorInList(in_list) {
    var bRemoveAll = true;
    
    
    for (var i = in_list.length - 1; i >= 0 ; i--) {
        var index = in_list[i];
        if (_pjList[index].kPJNameKey != "") {
            in_list.splice(i, 1);
            bRemoveAll = false;
        }
    }
    
    if (bRemoveAll) {
        in_list.splice(0, 1);
    }

    if (in_list.length > 0) {
        
        var removePJList = new Array();
        for (var i = 0; i < in_list.length; i++) {
            var index = in_list[i];
            var removePj = _pjList[index];
            removePJList.push(removePj);
        }
        if (removePJList.length > 0) {
            PostMessage(kCmdRemovePJSearchInfo, "", removePJList);
        }
        
        
        for (var i = in_list.length - 1; i >= 0; i--) {
            var index = in_list[i];
            
            
            _pjList.splice(index, 1);
            
            
            var removeRowIndex = document.getElementById(index).rowIndex;
            var table = document.getElementById('pjList');
            table.deleteRow( removeRowIndex );
        }
    }
}


function handleConnectEnd() {
	logMsg("call handleConnectEnd.");
	
	
	
	setTimeout(function () {
		connectProcess4();
	}, 3000 );
}


function handleDisconnectEnd() {
	logMsg("call handleDisconnectEnd.");

    
    
	if ( (_connectState >= kConnectState_Connecting)
          &&(_connectState < kConnectState_RequestDisonnectShowDialog)
        ) {
		
		removePreConnectSearchPJFromPJController();
			
		
		if (_localstream) {
			_localstream.getVideoTracks()[0].stop();
			_localstream = null;
		}
        
        
        enableSearchControls()
        
        
        
        
        chrome.runtime.getBackgroundPage(function(bg){
            if (bg.showSearchWindow) {
                bg.showSearchWindow();
            }
            
            bg.setConnectedPJList(null);
        });
        
        
        
        
        updateSearchList();

        _connectState = kConnectState_NotStarted;
	}
}


function handleConnectionError(pjerror, detail) {
  logMsg("call handleConnectionError.");
  logMsg("error=" + String(pjerror) + " detail=" + String(detail.kPJErrorKey));
  
  if (pjerror == kErrorCheckSuccess) {
      
	  
	  for(row=0; row < _pjList.length; row++){
		  var pjInfo = _pjList[row];
		  pjInfo.kPJRetryTimes = 0;
	  }
	  for(row=0; row < _preConnectSearchPjList.length; row++){
		  var pjInfo = _preConnectSearchPjList[row];
		  pjInfo.kPJRetryTimes = 0;
	  }
      connectProcess2();
  } else if (pjerror == kErrorKeyword) {
    
    var row=0;
	var pjInfo = null;
    for (row=0; row < _pjList.length; row++) {
        var idvalue = _pjList[row].kPJIDKey;
        if (idvalue == detail["kPJIDKey"]) {
			
            pjInfo = _pjList[row];
			break;
		}
	}
	
	if (pjInfo == null) {
		for (row=0; row < _preConnectSearchPjList.length; row++) {
			var idvalue = _preConnectSearchPjList[row].kPJIDKey;
			if (idvalue == detail["kPJIDKey"]) {
				pjInfo = _preConnectSearchPjList[row];
				break;
			}
		}
	}
	  
	
	if (pjInfo) {
		
		
		pjInfo.kPJKeywordStringKey = null;
		
		pjInfo.kPJRetryTimes++;

		
		
		if (pjInfo.kPJRetryTimes < 4) {
			connectProcess2();
		} else {
            _connectState = kConnectState_RequestDisonnectShowDialog;
			showDialogOnCurrentWindow(LZD_ERR_STR_WRONG_KEYWORD_LIMIT, connectCancel, null);
		}
	} else {
		
		
		showDialogOnCurrentWindow(LZD_ERR_STR_WRONG_KEYWORD_LIMIT, connectCancel, null);
	}

  } else {
      
      if (pjerror == kErrorPreConnectSearch) {
          pjerror = kErrorConnect;  
      }
      if (_connectState == kConnectState_RequestConnect) {
          
          hideConnecting();
      }
      _connectState = kConnectState_RequestDisonnectShowDialog;
	  showDialogOnCurrentWindow(pjerror, connectCancel, null);
		
		chrome.runtime.getBackgroundPage(function(bg){
			if (bg.showSearchWindow) {
				bg.showSearchWindow();
			}
			
			if (bg.closeWindowWithIgnorePjCtrlCleanupToolbarWindow) {
				bg.closeWindowWithIgnorePjCtrlCleanupToolbarWindow();
			}
		});
  }
}


function handlePreConnectSearchPJ(val) {
    var pjInfo = val["pjinfo"];
    var searchFlag = val["searchFlag"];
    
    
    if (indexOfProjectorInArray(pjInfo, _preConnectSearchPjList) >= 0) {
        return;
    }
    
    var index = indexOfProjectorInArray(pjInfo, _pjList);
    if (index == -1) {
        pjInfo.bSearchedFlag = searchFlag;
        _preConnectSearchPjList.push(pjInfo);
    } else {
        _preConnectSearchPjList.push(_pjList[index]);
    }
}


function removePreConnectSearchPJFromPJController() {
    if (_preConnectSearchPjList.length > 0) {
        var removePJList = new Array();
        for (var i = 0; i < _preConnectSearchPjList.length; i++) {
            var preConnectSearchPj = _preConnectSearchPjList[i];
            if (preConnectSearchPj.kPjAddPreConnectSearchPJ == 1) {
                
                delete preConnectSearchPj["kPjAddPreConnectSearchPJ"];
                removePJList.push(_preConnectSearchPjList[i]);
            }
        }
        if (removePJList.length > 0) {
            PostMessage(kCmdRemovePJSearchInfo, "", removePJList);
        }
    }
}


function enableSearchControls() {
    document.getElementById('pj-ip').disabled = false;
    document.getElementById('searchStart').disabled = false;
    document.getElementById('pj-search-list').disabled = false;
    updateConnectButtonState();
    
    $('tbody.scrollBody').data('contextMenuDisabled', false);

    
    updatePJListViewSelection();
}


function disableSearchControls() {
    document.getElementById('pj-ip').disabled = true;
    document.getElementById('pj-search-list').disabled = true;
    document.getElementById('searchStart').disabled = true;
    document.getElementById('captureStart').disabled = true;
    
    $('tbody.scrollBody').data('contextMenuDisabled', true);

    
    disablePJListViewCheckbox();
}


function disablePJListViewCheckbox() {
    
    for (var i = 0; i < _pjList.length; i++) {
        var pj = _pjList[i];
        if (pj.kPJSelectableKey == 1) {
            var curRow = $('#' + i);
            var checkbox = $(curRow).find('input:checkbox').eq(0);
            checkbox.prop("disabled", true);
        }
    }
}



function keydownPjKeyword(event){

	
	
	
	var bCtrlKey = false;
	if (window.navigator.platform.match(/MacIntel/)) {
		bCtrlKey = event.metaKey;
	} else {
		bCtrlKey = event.ctrlKey;
	}
	if ($.inArray(event.keyCode, [46, 8, 9, 27, 13, 37, 39]) !== -1 ||
	
	(event.keyCode == 65 && (bCtrlKey === true)) ||
	
	(event.keyCode == 67 && (bCtrlKey === true)) ||
	
	(event.keyCode == 88 && (bCtrlKey === true)) ||
	
	(event.keyCode == 86 && (bCtrlKey === true)) ) {
		return;
	}

	
	var tmp = String.fromCharCode(event.keyCode);
	if ((null != tmp[0].match(/^[0-9]+$/)) && (false == event.shiftKey)) {
		
	} else {
		
		event.preventDefault();
	}
}



function pastePjKeyword(event){
	var savedcontent = "";
	if (event && event.clipboardData && event.clipboardData.getData) { 
		
		var pasteData;
		if(event.clipboardData.types.indexOf('text/plain') > -1){
			pasteData = event.clipboardData.getData('text/plain');
		}
		else {
			pasteData = "";
		}

		
		pasteData = pasteData.replace(/[^0-9]/g, "");

		var maxlength = document.getElementById('kw-pjkeyword').maxLength;
		var value = document.getElementById('kw-pjkeyword').value;
		var pos = document.getElementById('kw-pjkeyword').selectionStart;
		var end = document.getElementById('kw-pjkeyword').selectionEnd;
		var length1 = document.getElementById('kw-pjkeyword').value.length;
		var length = pasteData.length;
		if (pasteData.length + value.length + pos - end > maxlength) pasteData = pasteData.substr(0, maxlength - length1 + end - pos);

		
		document.getElementById('kw-pjkeyword').value =  value.substr(0, pos) + pasteData + value.substr(end);
		length = pasteData.length;
		document.getElementById('kw-pjkeyword').selectionStart = pos + length;
		document.getElementById('kw-pjkeyword').selectionEnd = pos + length;

		
		event.preventDefault();
		return false;
	} else { 
		return true;
	}
}



function dropPjKeyword(event){
	
	event.preventDefault();
	return false;
}


function showKeyword(trialTimes, pjInfo, okCallback, cancelCallback) {
    var formdiv = $("#keyword-dialog");
    formdiv[0].style.display = "";
    
    if (trialTimes < 1) {
        $("#kw-message").html(chrome.i18n.getMessage("LZD_ERR_STR_NO_KEYWORD"));
    } else {
        $("#kw-message").html(chrome.i18n.getMessage("LZD_ERR_STR_FAILED_KEYWORD"));
    }
    $("#kw-pjip").val(pjInfo.kPJIPAddressKey);
    $("#kw-pjname").val(pjInfo.kPJNameKey);
    $("#kw-pjkeyword").val(""); 
    var input = $("#kw-pjkeyword");
    input[0].disabled = false;
    
    document.getElementById('kw-pjkeyword').addEventListener('keydown', keydownPjKeyword);
    document.getElementById('kw-pjkeyword').addEventListener('paste', pastePjKeyword);
    document.getElementById('kw-pjkeyword').addEventListener('drop', dropPjKeyword);
    
    $( "#keyword-dialog" ).dialog({
      resizable: false,
      modal: true,
      draggable: false,
      dialogClass: 'appDialog',
      buttons: [
          {
            text: chrome.i18n.getMessage("LZD_BTN_OK"),
            click: function() {
                logMsg("keyword:" + $("#kw-pjkeyword").val());
                pjInfo.kPJKeywordStringKey = $("#kw-pjkeyword").val();
                $( this ).dialog( "close" );
            }
          },
         {
            text: chrome.i18n.getMessage("LZD_BTN_CANCEL"),
            click: function() {
                logMsg("keyword:cancel");
                $( this ).dialog( "close" );
          }
        }
      ],
      open: function () {
        var okButton = $( this ).siblings('.ui-dialog-buttonpane').find('button:eq(0)');
        
        okButton.attr("disabled", true);
        
        var okButtonControl = function (event) {
          logMsg("keyword:" + $("#kw-pjkeyword").val());
          
          
          if ($("#kw-pjkeyword").val().length > 0) {
            okButton.attr("disabled", false);
            okButton.removeClass('ui-state-default').addClass('ui-state-hover');
            
            if (event.which == 13) {
              okButton.click();
            }
          } else {
            okButton.removeClass('ui-state-hover').addClass('ui-state-default');
            okButton.attr("disabled", true);
          }
        };
        
        
        $( this ).keyup(okButtonControl);
        
        okButton.mouseleave(okButtonControl);
      },
      close: function() {
        logMsg("keyword:close");
        var input = $("#kw-pjkeyword");
        input[0].disabled = true;
        if (pjInfo.kPJKeywordStringKey != null) {
            if(okCallback) {
                okCallback();
            }
        } else {
            if(cancelCallback) {
                cancelCallback();
            }
        }
      }
    }).parent().draggable({"containment": "window"});
}


function showConnecting() {
	var formdiv = $("#connecting-dialog");
	formdiv[0].style.display = "";
	
	$("#connecting-message").html(chrome.i18n.getMessage("LZD_QSTN_WAIT_ON_CONNECTING"));
	$( "#connecting-dialog" ).dialog({
		closeText: "test",
		resizable: false,
		draggable: false,
		dialogClass: 'appDialog',
		zIndex: 900,
		modal: true
	}).parent().draggable({"containment": "window"});
}


function hideConnecting() {
	logMsg("call hideConnecting.");
	
	if ($( "#connecting-dialog" ).dialog("isOpen")) {
		$( "#connecting-dialog" ).dialog("close");
	}
}


function gotStream(stream) {
	logMsg("Received local stream");

	_localstream = stream;

	
	connectProcess1();

	
	
	
	var track = _localstream.getVideoTracks()[0];
	track.onended = streamEnded;
}



function streamEnded() {
	logMsg("call streamEnded!!");
	
	
	requestDisconnect();

	_localstream = null;
}


function getUserMediaError() {
	logMsg("getUserMedia() failed.");
	
	
	requestDisconnect();
}


function onAccessApproved(id) {
	logMsg("call onAccessApproved.");

	if (!id) {
		
		logMsg("Access rejected.");
		
		requestDisconnect();
		
		return;
	}

	var frameRate = 20;

	var videoSetting = {
							chromeMediaSource: "desktop", 
							chromeMediaSourceId: id,
	};

    
    
	var width = _displayWidth;
	var height = _displayHeight;
    var maxWidth = 0;
    var maxHeight = 0;
    
    
    var aspectRatio = getAspectRatioWithDecimalPoint(_displayWidth, _displayHeight);
    
    switch (aspectRatio) {
        case "16:9":
            
            maxWidth = 1366;
            maxHeight = 768;
            break;
        case "4:3":
            
            maxWidth = 1024;
            maxHeight = 768;
            break;
        case "16:10":
            
        default:
            
            maxWidth = 1280;
            maxHeight = 800;
            break;
    }
    
    if(_displayHeight > _displayWidth) {
        var temp = maxWidth;
        maxWidth = maxHeight;
        maxHeight = temp;
    }
    
    if ( (_displayWidth < maxWidth)
        || (_displayHeight < maxHeight)
        ) {
        width = maxWidth;
        height = maxHeight;
    }
    
	logMsg("Setting info! ("+ width +", "+ height +") AspectRatio! ("+aspectRatio+")" );
	videoSetting = {
						chromeMediaSource: "desktop", 
						chromeMediaSourceId: id,
						
						maxWidth: width,
						
						maxHeight: height,
						minFrameRate: frameRate,
						maxFrameRate: frameRate,
	};

	
	navigator.webkitGetUserMedia({
		audio:false,
		video: { mandatory: videoSetting }
		}, gotStream, getUserMediaError);

		logMsg("Setting info! ("+ width +", "+ height +")" );
}


function getAspectRatioWithDecimalPoint(width, height) {
    if(height > width) {
        var temp = width;
        width = height;
        height = temp;
    }
    var ratio = width / height;
    var checkRatio4_3   = Math.abs( ratio - 4 / 3 );
    var checkRatio16_9  = Math.abs( ratio - 16 / 9 );
    var checkRatio16_10 = Math.abs( ratio - 16 / 10 );
    
    var ret = "";
    switch (Math.min(checkRatio4_3, checkRatio16_9, checkRatio16_10)) {
        case checkRatio4_3:
            ret = '4:3';
            break;
        case checkRatio16_9:
            ret = '16:9';
            break;
        case checkRatio16_10:
            ret = '16:10';
            break;
        default:
            break;
    }
    
    return ret;
}


function sendCaptureStream(s) {
  logMsg("call sendCaptureStream.");

  var key = "track";
  var val = s.getVideoTracks()[0];

  PostMessage(kCmdSendStreamData, key, val);
}


function onTimeoutAutoUpdateTimer(){
	var currentTime= new Date();
	var hour = currentTime.getHours();
	var minute = currentTime.getMinutes();
	var second = currentTime.getSeconds();
	logMsg("Scheduled Search Start. : " + hour + ":" + minute + ":" + second );

	
	_handleAutoUpdateTimer = null;

	
	updateSearchList();
}


function createAutoUpdateTimer(){

	
	if (null != _handleAutoUpdateTimer) {
		cancelAutoUpdateTimer();
	}

	
	_handleAutoUpdateTimer = setTimeout(onTimeoutAutoUpdateTimer, 60000);

	var currentTime= new Date();
	var hour = currentTime.getHours();
	var minute = currentTime.getMinutes();
	var second = currentTime.getSeconds();
	logMsg("createAutoUpdateTimer : " + hour + ":" + minute + ":" + second );
}


function cancelAutoUpdateTimer() {

	
	if (null != _handleAutoUpdateTimer) {
		clearTimeout(_handleAutoUpdateTimer);
		_handleAutoUpdateTimer = null;

		var currentTime= new Date();
		var hour = currentTime.getHours();
		var minute = currentTime.getMinutes();
		var second = currentTime.getSeconds();
		logMsg("cancelAutoUpdateTimer : " + hour + ":" + minute + ":" + second );
	}
}


onload = function() {
	localizeControls();
	attachListeners();

	
	_pjList = new Array();
	
	
	_preConnectSearchPjList = new Array();
    
    initContextMenu();
    
    initButtonStatus();

	chrome.runtime.getBackgroundPage(function(bg){
		if (bg.initSearchWindow) {
			bg.initSearchWindow(document);
		}
	});

	_pendingDisplayChangeToPJ = false;
	_handleAutoUpdateTimer = null;
	_pendingDisconnect = false;
}
