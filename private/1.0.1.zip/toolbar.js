
function doMinimize(event) {
	logMsg("call doMinimize!!");

	
	document.getElementById('minimize').style.display = 'none';

	
	chrome.app.window.current().minimize();
}


function doClose(event) {
	logMsg("call doClose!!");
	
	
	chrome.runtime.getBackgroundPage(function(bg) {
		bg.askLeaveToolbarWindow();
	});
}


function doProjection(event) {
	logMsg("call doProjection!!");
	
	
	PostMessage(kCmdScreenProjection, "", "");
}


function doDisconnect(event) {
	logMsg("call doDisconnect!!");
	
	
	chrome.runtime.getBackgroundPage(function(bg) {
		bg.askLeaveToolbarWindow();
	});
}


function doProjectorInfo(event) {
	logMsg("call doProjectorInfo!!");
	
	
	chrome.runtime.getBackgroundPage(function(bg) {
		bg.showPJInfoWindow();
	});
}


function updateProjectionConfig() {
	logMsg("call updateProjectionConfig!!");
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg.getProjectionConfig() == 3) {
			document.getElementById('projection').style.display = "none";
			chrome.app.window.current().innerBounds.width = 182;
		} else {
			chrome.app.window.current().innerBounds.width = 242;
			document.getElementById('projection').style.display = "table-cell";
		}
	});
}


function visibilityChanged() {
	logMsg("call visibilityChanged!!");
	
	if (window.navigator.platform.indexOf("Win") != -1) {
		logMsg("document.hidden:"+document.hidden, "document.visibilityState:"+document.visibilityState);
		if ("visible" == document.visibilityState) {
			updateProjectionConfig();
		}
	}
}


onload = function() {
	localizeControls();
	
	
	document.getElementById('minimize').addEventListener('click', doMinimize);
	document.getElementById('close').addEventListener('click', doClose);
	document.getElementById('projection').addEventListener('click', doProjection);
	document.getElementById('disconnect').addEventListener('click', doDisconnect);
	document.getElementById('projectorInfo').addEventListener('click', doProjectorInfo);
	
	document.addEventListener('visibilitychange', visibilityChanged, false);

	
	updateProjectionConfig();
}
