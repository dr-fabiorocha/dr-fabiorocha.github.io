var _dialog = null;


const LZD_DELETE_HISTORY							= 58;	
const LZD_QSTN_LEAVE								= 59;	


const LZD_ERR_STR_APP_ALREADY_RUNNING				= 60;	
const LZD_ERR_INITIALIZE							= 61;	
const LZD_ERR_STR_NON_SUPPORT_OS					= 62;	
const LZD_INSTALLER_BAD_FILES_EXISTS				= 63;	
const LZD_ERR_STR_NO_ENABLE_NETWORK_ADAPTER			= 64;	
const LZD_ERR_STR_WIFI_OFF							= 65;	
const LZD_ERR_STR_JOIN_EXCEED_MAX_NUMBER			= 66;	
const LZD_CAP_INPUT_KEYWORD							= 67;	
const LZD_ERR_STR_FAILED_KEYWORD					= 68;	
const LZD_ERR_STR_WRONG_KEYWORD_LIMIT				= 69;	
const LZD_ERR_STR_PROJECTOR_ANOTHER_CON_USED		= 70;	
const LZD_ERR_STR_WRONG_PROJECTOR_SELECT			= 71;	
const LZD_ERR_STR_NO_RESPONSE_REQUESTING_CONNECT	= 72;	
const LZD_ERR_STR_NETWORK_ERROR						= 73;	
const LZD_ERR_FAIL_CONNECT_PRJ						= 74;	
const LZD_ERR_STR_UPDATE							= 75;	
															
const LZD_ERR_STR_NS_DISCONNECTED_FROM_PRJ			= 76;	
const LZD_ERR_STR_NS_DISCONNECTED_FROM_MODERATOR	= 77;	
const LZD_QSTN_OTHERUSER_DISCONNECTED				= 78;	
const LZD_ERR_STR_USER_NAME_INPUT					= 79;	
const LZD_ERR_STR_PROFILE_NAME_MAX_OVER				= 80;	
const LZD_ERR_STR_FAIL_FILE_READ					= 81;	
const LZD_ERR_STR_FAIL_FILE_WRITE					= 82;	
const LZD_ERR_STR_APP_ERROR							= 83;	
const LZD_ERR_STR_INVALID_IP_ADDRESS				= 84;	


function showDialogOnCurrentWindow(key, button1Callback, button2Callback) {
	buildControls(key, button1Callback, button2Callback, true);
}


function isDialogWindowOpen() {
	if (_dialog && !_dialog.contentWindow.closed) {
		return true;
	}
	
	return false;
}


function showDialogWithPosition(key, position, button1Callback, button2Callback) {
	
	if (isDialogWindowOpen()) {
		focusDialogWindow();
		return;
	}
	
	var optionsDictionary = {};
	
	
	
	optionsDictionary.resizable = false;
	optionsDictionary.state = "normal";
	optionsDictionary.frame = "none";
	
	
	
	var dialogLeft = 0;
	var dialogTop = 0;
	var dialogWidth = 308;
	var dialogHeight = 180;
	if (position) {
		
		var baseScreen = position.baseScreen;
		dialogLeft = position.left;
		dialogTop = position.top;
		
		
		if (dialogLeft < baseScreen.availLeft) {
			dialogLeft = baseScreen.availLeft;
		}
		if (dialogLeft > baseScreen.availLeft + baseScreen.availWidth - dialogWidth) {
			dialogLeft = baseScreen.availLeft + baseScreen.availWidth - dialogWidth;
		}
		if (dialogTop < baseScreen.availTop) {
			dialogTop = baseScreen.availTop;
		}
		if (dialogTop > baseScreen.availTop + baseScreen.availHeight - dialogHeight) {
			dialogTop = baseScreen.availTop + baseScreen.availHeight - dialogHeight;
		}
	} else {
		
		dialogLeft = Math.floor((screen.availWidth - dialogWidth) / 2);
		dialogTop = Math.floor((screen.availHeight - dialogHeight) / 2);
	}
	optionsDictionary.outerBounds = {
		left:Math.floor(dialogLeft), top:Math.floor(dialogTop),
		width:Math.floor(dialogWidth), height:Math.floor(dialogHeight) };
	
	chrome.app.window.create('dialog.html', optionsDictionary, function(dialog) {
		_dialog = dialog;
		var selectButton1 = false;
		_dialog.contentWindow.onload = function() {
			if (_dialog && _dialog.contentWindow.buildControls) {
				_dialog.contentWindow.buildControls(key,
					function () {
						selectButton1 = true;
						_dialog.close();
					},
					function () {
						selectButton1 = false;
						_dialog.close();
				}, false);
			}
		};
		_dialog.onClosed.addListener(function() {
				_dialog = null;
				if (selectButton1) {
					if (button1Callback) {
						button1Callback();
					}
				} else {
					if (button2Callback) {
						button2Callback();
					}
				}
		});
	});
}


function focusDialogWindow() {
	if (isDialogWindowOpen()) {
		_dialog.focus();
	}
}


function closeDialogWindow() {
	if (isDialogWindowOpen()) {
		_dialog.close();
	}
}



function buildControls(key, button1Callback, button2Callback, insideWindow) {
	var message = null;
	var button1 = null;
	var button2 = null;
	var selectedCallback = null;

	
	switch (key) {
	case LZD_DELETE_HISTORY:	
		message = chrome.i18n.getMessage("LZD_DELETE_HISTORY");
		button1 = chrome.i18n.getMessage("LZD_BTN_YES");
		button2 = chrome.i18n.getMessage("LZD_BTN_NO");
		selectedCallback = button2Callback; 
	break;
	case LZD_QSTN_LEAVE:	
		message = chrome.i18n.getMessage("LZD_QSTN_LEAVE");
		button1 = chrome.i18n.getMessage("LZD_BTN_YES");
		button2 = chrome.i18n.getMessage("LZD_BTN_NO");
		selectedCallback = button2Callback; 
	break;
	case LZD_ERR_STR_APP_ALREADY_RUNNING:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_APP_ALREADY_RUNNING");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_INITIALIZE:	
		message = chrome.i18n.getMessage("LZD_ERR_INITIALIZE");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NON_SUPPORT_OS:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NON_SUPPORT_OS");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_INSTALLER_BAD_FILES_EXISTS:	
		message = chrome.i18n.getMessage("LZD_INSTALLER_BAD_FILES_EXISTS");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NO_ENABLE_NETWORK_ADAPTER:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NO_ENABLE_NETWORK_ADAPTER");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_WIFI_OFF:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_WIFI_OFF");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_JOIN_EXCEED_MAX_NUMBER:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_JOIN_EXCEED_MAX_NUMBER");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_CAP_INPUT_KEYWORD:	
		message = chrome.i18n.getMessage("LZD_CAP_INPUT_KEYWORD");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_FAILED_KEYWORD:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_FAILED_KEYWORD");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_WRONG_KEYWORD_LIMIT:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_WRONG_KEYWORD_LIMIT");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_PROJECTOR_ANOTHER_CON_USED:	
	case LZD_ERR_STR_WRONG_PROJECTOR_SELECT:		
		message = chrome.i18n.getMessage("LZD_ERR_STR_PROJECTOR_ANOTHER_CON_USED") + "<br/>" + chrome.i18n.getMessage("LZD_ERR_STR_WRONG_PROJECTOR_SELECT");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NO_RESPONSE_REQUESTING_CONNECT:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NO_RESPONSE_REQUESTING_CONNECT");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NETWORK_ERROR:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NETWORK_ERROR");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_FAIL_CONNECT_PRJ:	
		message = chrome.i18n.getMessage("LZD_ERR_FAIL_CONNECT_PRJ");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_UPDATE:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_UPDATE");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NS_DISCONNECTED_FROM_PRJ:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NS_DISCONNECTED_FROM_PRJ");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_NS_DISCONNECTED_FROM_MODERATOR:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_NS_DISCONNECTED_FROM_MODERATOR");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_QSTN_OTHERUSER_DISCONNECTED:	
		message = chrome.i18n.getMessage("LZD_QSTN_OTHERUSER_DISCONNECTED");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_USER_NAME_INPUT:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_USER_NAME_INPUT");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_PROFILE_NAME_MAX_OVER:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_PROFILE_NAME_MAX_OVER");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_FAIL_FILE_READ:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_FAIL_FILE_READ");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_FAIL_FILE_WRITE:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_FAIL_FILE_WRITE");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_APP_ERROR:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_APP_ERROR");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	case LZD_ERR_STR_INVALID_IP_ADDRESS:	
		message = chrome.i18n.getMessage("LZD_ERR_STR_INVALID_IP_ADDRESS");
		button1 = chrome.i18n.getMessage("LZD_BTN_OK");
		selectedCallback = button1Callback; 
	break;
	default:
		
		return;
	break;
	}
	
	
	var buttons = [
		
		{
			text: button1, 
			click: function() {
				selectedCallback = button1Callback;
				$( this ).dialog( "close" );
			}
		}
	];
	if (button2) {
		
		buttons[1] = 
			{
				text: button2, 
				click: function() {
					selectedCallback = button2Callback;
					$( this ).dialog( "close" );
				}
			}; 
	}
	
	$( "#dialog-message" ).html(message);
	var options = {
		resizable: false,
		modal: true,
		draggable: false,
		dialogClass: 'appDialog', 
		                          
		buttons: buttons,
		close: function() {
			if (selectedCallback) {
				selectedCallback();
			}

			
			$(this).dialog("destroy");

			
			var formdiv = $("#dialog-div");
			formdiv[0].style.display = "none";
		}
	};
	
	
	var formdiv = $("#dialog-div");
	formdiv[0].style.display = "";
	
	if (insideWindow) {
		
		$( "#dialog-div" ).dialog(options).parent().draggable({"containment": "window"});
	} else {
		
		options.width = 300;
		options.height = 180;
		
		
		$( "#dialog-div" ).dialog(options);
	}
}
