var _searchWindow = null;
var _searchWindowShow = false; 
var _eulaWindow = null;
var _splashWindow = null;
var _toolbarWindow = null;
var _toolbarWindowShow = false; 
var _toolbarWindowResize = false;
var _toolbarWindowResizePosX = 0;
var _toolbarWindowResizePosY = 0;
var _pjinfoWindow = null;
var _optionWindow = null;
var _supportWindow = null;



var _syncSettings = null;
var _localSettings = null;

var _pjController = null;
var _ignorePjCtrlCleanUp = false;
var _pjCtrlCleanupProcessing = false;
var _pjCtrlDisconnectProcessing = false;

var _connectedPJList = null;
var _pjConfig = -1;

var _displayRotation = 0;
var _myScreenAvailWidth = 0;
var _myScreenAvailHeight = 0;



function logBackGroundMessage(message) {
	
}


function closeWindowWithIgnorePjCtrlCleanup(targetWindow) {
	if (targetWindow && !targetWindow.contentWindow.closed) {
		_ignorePjCtrlCleanUp = true;
		targetWindow.close();
	}
}


function closeWindowWithIgnorePjCtrlCleanupToolbarWindow() {
	closeWindowWithIgnorePjCtrlCleanup(_toolbarWindow);
}


function checkChromeVersion() {
	var isSupport = false;
	
	var chromeVersion = getChromeVersion();
	logBackGroundMessage("ChromeVersion:"+chromeVersion);
	var version = parseFloat(chromeVersion);
	if (version >= 49.0) {
		isSupport = true;
	}
	
	return isSupport;
}


function activateApp() {
  if (_optionWindow && !_optionWindow.contentWindow.closed) {
    _optionWindow.focus();
    return true;
  } else if (isToolbarWindowShow()) {
    
    
    focusToolbarWindow();
    return true;
  } else if (_eulaWindow && !_eulaWindow.contentWindow.closed) {
    _eulaWindow.focus();
    return true;
  } else if (_splashWindow && !_splashWindow.contentWindow.closed) {
    _splashWindow.focus();
    return true;
  } else if (isSearchWindowShow()) {
    
    
    focusSearchWindow();
    return true;
  } else if (isDialogWindowOpen()) {
    
    focusDialogWindow();
    return true;
  } else if (_supportWindow && !_supportWindow.contentWindow.closed) {
	  _supportWindow.focus();
	  return true;
  }
  return false;
}


function checkFirstLaunched() {
	var isFirstLaunched = false;
	
	
	var appVersion = chrome.runtime.getManifest().version;
	
	logBackGroundMessage("AppVersion   : " + appVersion);
	
	
	if (_syncSettings.AgreeVersion === undefined || _syncSettings.AgreeVersion === "") {
		isFirstLaunched = true;
		logBackGroundMessage("AgreeVersion : " + "undefined.");
	} else {
		logBackGroundMessage("AgreeVersion : " + _syncSettings.AgreeVersion);
	}
	
	return isFirstLaunched;
}


function checkNaClFirstTranslated() {
	var isFirstTranslated = false;
	
	
	var appVersion = chrome.runtime.getManifest().version;
	
	logBackGroundMessage("AppVersion   : " + appVersion);
	
	
	
	if (_localSettings.LoadVersion === ""
		|| _localSettings.LoadVersion < appVersion) {
		isFirstTranslated = true;
		logBackGroundMessage("LoadVersion  : " + "undefined.");
	} else {
		logBackGroundMessage("LoadVersion  : " + _localSettings.LoadVersion);
	}
	
	return isFirstTranslated;
}


function checkWirelessLanConnected(callback) {
	
	chrome.system.network.getNetworkInterfaces(function(interfaces){
		logBackGroundMessage(interfaces);
		
		var isConnected = false;
		if (interfaces.length > 0) {
			isConnected = true;
		}
		if (callback) {
			callback(isConnected);
		}
	});
}


function getDefaultSettings(callback) {
	var defaultSettings	=	{
								AgreeVersion:		"",								
								UserName:			"",								
								SearchList:			[],								
								Band:				kOptionBandDefault,				
								LowerResolution:	kOptionLowerResolutionDefault,	
							};
	
	
	chrome.identity.getProfileUserInfo(function(userInfo) {
		if (userInfo.email.length == 0) {
			
			defaultSettings.UserName = "Guest";
		} else if (userInfo.email.length <= 32) {
			
		   defaultSettings.UserName = userInfo.email;
		} else {
			
			defaultSettings.UserName = userInfo.email.substring(0,32);
		}
		
		if (callback) {
			callback(defaultSettings);
		}
	});
}


function getDefaultLocalSettings() {
	var defaultLocalSettings = {
									LoadVersion:	"",	
								};
	return defaultLocalSettings;
}


function readSettingsFromStorage(callback) {
	var syncStorage = null;
	var localStorage = null;

	var loadComplete = function () {
		if (!localStorage || !syncStorage) {
			return;
		}
		_syncSettings = syncStorage;
		_localSettings = localStorage;
    
		if (callback) {
			callback();
		}
	};
	
	chrome.storage.sync.get("iProjectionSettings",
							function (fromStorage) {
								if (fromStorage.iProjectionSettings === undefined) {
									getDefaultSettings(function (defaultSettings) {
										if (!defaultSettings) {
											return;
										}
										syncStorage = defaultSettings;
										loadComplete();
									});
								} else {
									syncStorage = fromStorage.iProjectionSettings;
									loadComplete();
								}
							});
	chrome.storage.local.get("iProjectionLocalSettings",
							 function (fromStorage) {
								if (fromStorage.iProjectionLocalSettings === undefined) {
									localStorage = getDefaultLocalSettings();
								} else {
									localStorage = fromStorage.iProjectionLocalSettings;
								}
								loadComplete();
							 });
}


function writeSettingsToStorage(callback) {
	var syncResult = false;
	
	var writeComplete = function () {
		if (!syncResult) {
			return;
		}
		
		if (callback) {
			callback();
		}
	};
	
	chrome.storage.sync.set({ "iProjectionSettings": _syncSettings },
							function () {
								if (chrome.runtime.error) {
									logBackGroundMessage("Runtime Error. [chrome.storage.sync.set]");
								}
								syncResult = true;
								writeComplete();
							});
}


function writeLocalSettingsToStorage(callback) {
	var localResult = false;
	
	var writeComplete = function () {
		if (!localResult) {
			return;
		}
		
		if (callback) {
			callback();
		}
	};
	
	chrome.storage.local.set({ "iProjectionLocalSettings" : _localSettings },
							 function () {
								if (chrome.runtime.error) {
									logBackGroundMessage("Runtime Error. [chrome.storage.local.set]");
								}
								localResult = true;
								writeComplete();
							 });
}


function isSearchWindowOpen() {
	if (_searchWindow && !_searchWindow.contentWindow.closed) {
		return true;
	}
	
	return false;
}


function isSearchWindowShow() {
	if (isSearchWindowOpen() && _searchWindowShow) {
		return true;
	}
	
	return false;
}


function showSearchWindow(callback) {
	logBackGroundMessage("call showSearchWindow.");
	
	if (isSearchWindowOpen()) {
		
		if (_searchWindowShow == false) {
			_searchWindow.show();
			_searchWindowShow = true;
		}
		return;
	}
	
	
	checkWirelessLanConnected(function(isConnected) {
		if (isConnected) {
			createSearchWindow();
		} else {
			showDialogWithPosition(LZD_ERR_STR_WIFI_OFF, null, function() {
                onPjCtrlCleanUp();
			}, null);
		}
		
		if (callback) {
			callback();
		}
	});
}


function hideSearchWindow() {
	if (isSearchWindowShow()) {
		_searchWindow.hide();
		_searchWindowShow = false;
	}
}


function closeSearchWindow() {
	if (isSearchWindowOpen()) {
		_searchWindow.close();
	}
}


function minimizeSearchWindow() {
	if (_searchWindow && !_searchWindow.contentWindow.closed) {
		_searchWindow.minimize();
	}
}


function focusSearchWindow() {
	if (isSearchWindowShow()) {
		_searchWindow.focus();
	}
}



function createSearchWindow() {
  logBackGroundMessage("call createSearchWindow.");

  var xhr = new XMLHttpRequest();
  xhr.open('GET', 'run_package_config', true);
  xhr.onload = function() {
    var toolchain_config = this.responseText.split(' ');
    createWindow(makeURL.apply(null, toolchain_config));
  };
  xhr.onerror = function() {
    
      createWindow('search.html');
  };
  xhr.send();

}


function isToolbarWindowOpen() {
	if (_toolbarWindow && !_toolbarWindow.contentWindow.closed) {
		return true;
	}
	
	return false;
}


function isToolbarWindowShow() {
	if (isToolbarWindowOpen() && _toolbarWindowShow) {
		return true;
	}
	
	return false;
}


function showToolbarWindow(minimize) {
	logBackGroundMessage("call showToolbarWindow.");
	
	
	if (isToolbarWindowOpen()) {
		
		if (_toolbarWindowShow == false) {
			_toolbarWindow.show();
			_toolbarWindowShow = true;
		}
		return;
	}

	createToolbarWindow(minimize);
}


function hideToolbarWindow() {
	if (isToolbarWindowShow()) {
		_toolbarWindow.hide();
		_toolbarWindowShow = false;
	}
}


function focusToolbarWindow() {
	if (isToolbarWindowShow()) {
		_toolbarWindow.focus();
	}
}


function closeToolbarWindow() {
	if (isToolbarWindowOpen()) {
		_toolbarWindow.close();
	}
}


function getProjectionConfig() {
	return _pjConfig;
}


function setProjectionConfig(pjConfig) {
	logBackGroundMessage("call setProjectionConfig.");
	
	_pjConfig = pjConfig;
	
	
	if (_toolbarWindow) {
		if ((!isToolbarWindowShow()) || (_toolbarWindow.isMinimized())) {
			
			_toolbarWindow.contentWindow.updateProjectionConfig();
		} else {
			

			
			_toolbarWindowResizePosX = _toolbarWindow.innerBounds.left;
			_toolbarWindowResizePosY = _toolbarWindow.innerBounds.top;

			
			_toolbarWindowResize = true;
			_toolbarWindow.close();
		}
	}
}


function createToolbarWindow(minimize) {
	logBackGroundMessage("call createToolbarWindow.");

	var optionsDictionary = {};
	
	optionsDictionary.resizable = false;

	
	if (minimize) {
		optionsDictionary.state = "minimized";
	} else {
		optionsDictionary.state = "normal";
	}

	optionsDictionary.frame = "none";

	var windowWidth = 0;
	var windowHeight = 0;
	var windowPosX = 0;
	var windowPosY = 0;

	if (_pjConfig == 3) {
		windowWidth = 182;
	} else {
		windowWidth = 242;
	}
	windowHeight = 85;
	if (true == _toolbarWindowResize) {
		
		windowPosX = _toolbarWindowResizePosX;
		windowPosY = _toolbarWindowResizePosY;
	} else {
		
		windowPosX = (screen.availWidth / 2);
		windowPosY = ((screen.availHeight - windowHeight) - 5);
	}
	optionsDictionary.innerBounds = {
		width:  Math.floor(windowWidth), 
		height: Math.floor(windowHeight), 
		left:   Math.floor(windowPosX), 
		top:    Math.floor(windowPosY)
	};

	chrome.app.window.create('toolbar.html', optionsDictionary, function(toolbar) {
		_toolbarWindow = toolbar;
		_toolbarWindowShow = true;

		
		_toolbarWindow.onClosed.addListener(function(){
			_toolbarWindowShow = false;
			if (false == _toolbarWindowResize) {
				
				closePJInfoWindow();
				onPjCtrlCleanUp();
			} else {
				createToolbarWindow(_toolbarWindow.isMinimized());
			}
		});

		
		_toolbarWindow.onRestored.addListener(function(){
			var doc = _toolbarWindow.contentWindow.document;

			
			doc.getElementById('minimize').style.display = 'inline-block';
		});

		
		_toolbarWindowResize = false;
	});
}


function askLeaveToolbarWindow() {
	logBackGroundMessage("call askLeaveToolbarWindow.");
	
	
	hideToolbarWindow();
	
	setTimeout(function () {
		
		var position = { top: _toolbarWindow.innerBounds.top, left:_toolbarWindow.innerBounds.left,
			baseScreen: _toolbarWindow.contentWindow.screen };
		
		
		showDialogWithPosition(LZD_QSTN_LEAVE, position,
		function () {
			
			
			closeWindowWithIgnorePjCtrlCleanup(_toolbarWindow);
			_toolbarWindow = null;
			
			
			_pjController.postMessage(kCmdCaptureCancel, "", "");
            _pjCtrlDisconnectProcessing = true;
		},
		function () {
			
			
			
			
			if (isToolbarWindowOpen()) {
				showToolbarWindow(false);
			}
		});
	}, 10); 
}


function showPJInfoWindow() {
	logBackGroundMessage("call showPJInfoWindow.");
	
	
	if (_pjinfoWindow && !_pjinfoWindow.contentWindow.closed) {
		_pjinfoWindow.focus();
		return;
	}

	var optionsDictionary = {};

	
	optionsDictionary.resizable = false;
	optionsDictionary.state = "normal";
	var screenWidth = screen.availWidth;
	var screenHeight = screen.availHeight;
	var width = 300;
	var height = 91 + (76 * getConnectedPJList().length);

	optionsDictionary.innerBounds = {
		width:  Math.floor(width),
		height: Math.floor(height),
		left:   Math.floor((screenWidth - width) / 2),
		top:    Math.floor((screenHeight - height) / 2)
	};

	chrome.app.window.create('pjinfo.html', optionsDictionary, function(pjinfo) {
		_pjinfoWindow = pjinfo;
	});
}


function closePJInfoWindow() {
	if (_pjinfoWindow && !_pjinfoWindow.contentWindow.closed) {
		_pjinfoWindow.close();
		_pjinfoWindow = null;
	}
}


function showEULAWindow() {
  
  if (_eulaWindow && !_eulaWindow.contentWindow.closed) {
    _eulaWindow.focus();
    return;
  }

  
  logBackGroundMessage("call showEULAWindow.");
  
  
  var optionsDictionary = {};
  var screenWidth = screen.availWidth;
  var screenHeight = screen.availHeight;
  var width = 506;
  var height = 440;

  optionsDictionary.innerBounds = {
    width:  Math.floor(width),
    height: Math.floor(height),
    left:   Math.floor((screenWidth - width) / 2),
    top:    Math.floor((screenHeight - height) / 2)
  };
  optionsDictionary.state = "normal";	
  optionsDictionary.frame = "chrome";	
  optionsDictionary.focused = true;
  optionsDictionary.resizable = false;

  chrome.app.window.create('eula.html', optionsDictionary, function(window) {
    _eulaWindow = window;
	_eulaWindow.onClosed.addListener(function () {
		onPjCtrlCleanUp();
	});
  });
}


function showSplashWindow() {
  
  if (_splashWindow && !_splashWindow.contentWindow.closed) {
    _splashWindow.focus();
    return;
  }

  logBackGroundMessage("call showSplashWindow.");
  
  
  var optionsDictionary = {};
  var screenWidth = screen.availWidth;
  var screenHeight = screen.availHeight;
  var width = 440;
  var height = 280;

  optionsDictionary.innerBounds = {
    width:  Math.floor(width),
    height: Math.floor(height),
    left:   Math.floor((screenWidth - width) / 2),
    top:    Math.floor((screenHeight - height) / 2)
  };
  optionsDictionary.resizable = false;
  optionsDictionary.state = "normal";	
  optionsDictionary.frame = "none";	

  chrome.app.window.create('splash.html', optionsDictionary, function(window){
    _splashWindow = window;
	_splashWindow.onClosed.addListener(function () {
		onPjCtrlCleanUp();
	});
  });
  
}



function makeURL(toolchain, config) {
  return 'search.html?tc=' + toolchain + '&config=' + config;
}


function createWindow(url) {
	
	if (isSearchWindowOpen()) {
		
		if (_searchWindowShow == false) {
			_searchWindow.show();
			_searchWindowShow = true;
		}
		return;
	}
	
	logBackGroundMessage('loading ' + url);
	
	var optionsDictionary = {};
	var width = 640;
	var height = 497;
	var screenWidth = screen.availWidth;
	var screenHeight = screen.availHeight;
	
	
	optionsDictionary.innerBounds = {
		width:  Math.floor(width),
		height: Math.floor(height),
		left:   Math.floor((screenWidth - width) / 2),
		top:    Math.floor((screenHeight - height) / 2)
	};
	optionsDictionary.resizable = false;
	optionsDictionary.frame = "none";

	chrome.app.window.create(url, optionsDictionary,function(window){
		_searchWindow = window;
		_searchWindowShow = true;
		
		_myScreenAvailWidth = _searchWindow.contentWindow.screen.availWidth;
		_myScreenAvailHeight = _searchWindow.contentWindow.screen.availHeight;

		updateStatus();

		_searchWindow.onClosed.addListener(function(){
			_searchWindowShow = false;
			writeSettingsToStorage();
			closeSupportWindow();
			onPjCtrlCleanUp();
			
			
			
			
			
			
			
		});

		
		_searchWindow.onRestored.addListener(function(){
			var doc = _searchWindow.contentWindow.document;

			
			initSearchWindow(doc);

			
			doc.getElementById('minimize').style.display = 'inline-block';
		});

		
		_searchWindow.onBoundsChanged.addListener(function(){
			
			var searchWindowPosX = _searchWindow.innerBounds.left;
			var searchWindowPosY = _searchWindow.innerBounds.top;

			setTimeout(function () {
				
				if (	(searchWindowPosX == _searchWindow.innerBounds.left)	&& 
						(searchWindowPosY == _searchWindow.innerBounds.top)	) {

					
					var myScreenAvailWidth = _searchWindow.contentWindow.screen.availWidth;
					var myScreenAvailHeight = _searchWindow.contentWindow.screen.availHeight;
					if ((_myScreenAvailWidth != myScreenAvailWidth) || (_myScreenAvailHeight != _myScreenAvailHeight)) {
						
						initSearchWindow(_searchWindow.contentWindow.document);
					}
					_myScreenAvailWidth = myScreenAvailWidth;
					_myScreenAvailHeight = myScreenAvailHeight;
				}
			}, 1000);
		});


	});
}


function initSearchWindow(targetDocument) {

	
	var windowWidth = 640;
	var windowHeight = 497;
	var titlebarHeight = 33;

	
	var currentScreenWidth = _searchWindow.contentWindow.screen.availWidth;
	var currentScreenHeight = _searchWindow.contentWindow.screen.availHeight;

	
	var windowPosX = _searchWindow.innerBounds.left;
	var windowPosY = _searchWindow.innerBounds.top;

	
	targetDocument.getElementById('search_body').style.overflowX = 'hidden';
	targetDocument.getElementById('search_body').style.overflowY = 'hidden';
	targetDocument.getElementById('searchitemsarea').style.overflowX = 'hidden';
	targetDocument.getElementById('searchitemsarea').style.overflowY = 'hidden';

	
	if (currentScreenWidth >= windowWidth) {
		
		_searchWindow.innerBounds.width = windowWidth;
		$('#search_body', targetDocument).width(windowWidth);	
	} else {
		
		_searchWindow.innerBounds.width = currentScreenWidth;
		$('#search_body', targetDocument).width(currentScreenWidth);	
		targetDocument.getElementById('search_body').style.overflowX = 'auto';
	}

	
	if (currentScreenHeight >= windowHeight) {
		_searchWindow.innerBounds.height = windowHeight;
		$('#searchitemsarea', targetDocument).height(windowHeight - titlebarHeight);	
	} else {
		_searchWindow.innerBounds.height = currentScreenHeight;
		$('#searchitemsarea', targetDocument).height(currentScreenHeight - titlebarHeight);	
		targetDocument.getElementById('searchitemsarea').style.overflowY = 'auto';
	}

	
	
}


function showOptionWindow() {
	
	if (_optionWindow && !_optionWindow.contentWindow.closed) {
		_optionWindow.focus();
		return;
	}
	
	var screenWidth = screen.availWidth;
	var screenHeight = screen.availHeight;
	var width = 355;
	var height = 312;
	
	var optionsDictionary = {};
	


	
	optionsDictionary.innerBounds = {
		width:  Math.floor(width),
		height: Math.floor(height),
		left:   Math.floor((screenWidth - width) / 2),
		top:    Math.floor((screenHeight - height) / 2)
	};
	optionsDictionary.resizable = false;


	chrome.app.window.create('option.html',
							 optionsDictionary,
							 function(window){
								_optionWindow = window;
							 
								
								hideSearchWindow();
								
								_optionWindow.onClosed.addListener(function(){
									writeSettingsToStorage();
									_searchWindow.contentWindow.loadSearchedProjectorList();
									
									
									_searchWindow.show();
									_searchWindowShow = true;
								});
							 });
}


function showSupportWindow() {
	
	if (_supportWindow && !_supportWindow.contentWindow.closed) {
		_supportWindow.focus();
		return;
	}
	
	logBackGroundMessage("call showSupportWindow.");
	
	var screenWidth = screen.availWidth;
	var screenHeight = screen.availHeight;
	var width = 520;
	var height = 493;
	var uiLanguage = chrome.i18n.getUILanguage();
	
	chrome.app.window.create("support.html",
		{
			innerBounds: {
				width:  Math.floor(width),
				height: Math.floor(height),
				left:   Math.floor((screenWidth - width) / 2),
				top:    Math.floor((screenHeight - height) / 2)
			},
			resizable: false
		},
		function(window){
			_supportWindow = window;
		}
	);
	
}


function closeSupportWindow() {
	if (_supportWindow && !_supportWindow.contentWindow.closed) {
		_supportWindow.close();
		_supportWindow = null;
	}
}


















	








function clearLogMessage(msg) {
    
    
    
}


function updateLogMessage(msg) {
    
    
    
    
    
}


var statusText = 'NO-STATUS';
function updateStatus() {
	
	
	
	
	
	
	
	
}



function onLaunched(launchData) {
	logBackGroundMessage("call onLaunched.");

	
	
	if ("reload" != launchData.source) {
		if ((true == _pjCtrlCleanupProcessing)
            || (true == _pjCtrlDisconnectProcessing)
            ) {
			showSplashWindow();	
			setTimeout(function () {	
				chrome.runtime.reload();  
			}, 1000);	
			return;	
		}
	}

	if (false === checkChromeVersion()) {
		showDialogWithPosition(LZD_ERR_STR_NON_SUPPORT_OS, null, function() {
				
			},
			null);
		return;
	}
	if (true === activateApp()) {
		return;
	}
	
	readSettingsFromStorage(function() {
	
		
		createPjController();
	  
        
        chrome.system.display.getInfo(function(displayInfo) {
                                      var info = displayInfo[0];
                                      _displayRotation = info.rotation;
                                      });
        
        chrome.system.display.onDisplayChanged.addListener(onDisplayChanged);
		chrome.idle.onStateChanged.addListener(onStateChanged);
                            
       

        
                            
		
		if (true === checkFirstLaunched()) {
			showEULAWindow();
		} else {
			if (true === checkNaClFirstTranslated()) {
				
				showSplashWindow();
			} else {
				
				showSearchWindow();
			}
		}
	});
}

chrome.app.runtime.onLaunched.addListener(onLaunched);


function onDisplayChanged() {
	logMsg("Display Changed - background");

	
	if (_searchWindow) {
		var flg = _searchWindow.contentWindow.isEnabledDisplayChangeToPJ();
		if (2 == flg) {
			logMsg("--- Display Changed - background - PJ(2)");
			
		} else if (1 == flg) {
			logMsg("--- Display Changed - background - PJ(1)");
			
			_searchWindow.contentWindow.setPendingDisplayChangeToPJ(true);
		} else {
			logMsg("--- Display Changed - background - PJ(0)");
			

			
			_searchWindow.contentWindow.setPendingDisplayChangeToPJ(false);

			
			PostMessage(kCmdPauseGetFrame, "Frame", "Pause");

			
			chrome.system.display.getInfo(function(displayInfo) {

				
				var info = displayInfo[0];
				var x = info.bounds.left;
				var y = info.bounds.top;
				var w = info.bounds.width;
				var h = info.bounds.height;

				
				_searchWindow.contentWindow.setDisplayBounds(x,y,w,h);

				
				var key = "DisplaySize";
				var dict = new Array({key: "boundX", value: x},
				                     {key: "boundY", value: y},
				                     {key: "width", value: w},
				                     {key: "height", value: h});
				
				PostMessage(kCmdDisplayChanged, key, dict);

				logMsg("Display info! ("+ x +", "+ y +", "+ w +", "+ h +")" );
			});
		}
	}

	
	chrome.system.display.getInfo(function(displayInfo) {
		logMsg("--- Display Changed - background - getInfo()");
		var info = displayInfo[0];

		
		_myScreenAvailWidth = _searchWindow.contentWindow.screen.availWidth;
		_myScreenAvailHeight = _searchWindow.contentWindow.screen.availHeight;

		
		if (_searchWindow) {
			_searchWindow.contentWindow.onDisplayChanged(_displayRotation, info.rotation);
		}
		if (_optionWindow) {
			_optionWindow.contentWindow.onDisplayChanged(_displayRotation, info.rotation);
		}

		
		_displayRotation = info.rotation;
	});

}


function onStateChanged(newState) {
	logMsg("State Changed - background");
	
	if (_searchWindow) {
		
		if (newState === "locked") {
			_searchWindow.contentWindow.requestDisconnect();
		}
	}
}


function onEulaAgree() {

	
	var appVersion = chrome.runtime.getManifest().version;
	_syncSettings.AgreeVersion = appVersion;
	writeSettingsToStorage();
	
	
	
	if (_pjController.naclStatus_ === 'RUNNING') {
		
		
		showSearchWindow(function() {
			
			closeWindowWithIgnorePjCtrlCleanup(_eulaWindow);
			_eulaWindow = null;
		});
	} else {
		showSplashWindow();
		
		
		closeWindowWithIgnorePjCtrlCleanup(_eulaWindow);
		_eulaWindow = null;
	}
}


function onEulaDisagree() {
  _eulaWindow.close();
}


function onPjCtrlCleanUp() {
  
  if (_ignorePjCtrlCleanUp == true) {
	_ignorePjCtrlCleanUp = false;
	return;
  }
	
  
  if (_pjCtrlCleanupProcessing) {
	  return;
  }
	
  _pjCtrlCleanupProcessing = true;
	
  logBackGroundMessage("call onPjCtrlCleanUp.");
  _pjController.postMessage(kCmdCleanUp, "", "");
}


chrome.runtime.onStartup.addListener(function() {
  logBackGroundMessage("call onStartup.");
});

chrome.runtime.onInstalled.addListener(function() {
  logBackGroundMessage("call onInstalled.");
});

chrome.runtime.onStartup.addListener(function() {
  logBackGroundMessage("call onStartup.");
});

chrome.runtime.onSuspend.addListener(function() {
  logBackGroundMessage("call onSuspend.");
});

chrome.runtime.onSuspendCanceled.addListener(function() {
  logBackGroundMessage("call onSuspendCanceled.");
});

chrome.runtime.onConnect.addListener(function() {
  logBackGroundMessage("call onConnect.");
});

chrome.runtime.getBackgroundPage(function(ev) {
  logBackGroundMessage("call getBackgroundPage.");
});



function moduleLoadStart() {
	logBackGroundMessage("call moduleLoadStart");
}


function moduleLoadProgress() {
	logBackGroundMessage("call moduleLoadProgress");
}


function moduleDidLoad() {
	logBackGroundMessage("call moduleDidLoad");
	updateStatus();
	
	
	var appVersion = chrome.runtime.getManifest().version;
	_localSettings.LoadVersion = appVersion;
	writeLocalSettingsToStorage();
	
	
	if (_splashWindow !== null) {
		showSearchWindow(function() {
			closeWindowWithIgnorePjCtrlCleanup(_splashWindow);
			_splashWindow = null;
		});
	}
};


function handleMessage(message_event) {
	logBackGroundMessage("call handleMessage  [data]: " + message_event.data + "  [cmd]: " + message_event.data["cmd"]);
	
	var val = message_event.data;
	var msg = "";
	
	if ( typeof val == "string" ) {

		msg = val;
    } else if ( val instanceof Object ) {

		
		var cmd = val["cmd"];
		
		if ( kCmdJSSearchPJ == cmd ) {
			if (_searchWindow && _searchWindow.contentWindow.handleSearchPJ) {
				_searchWindow.contentWindow.handleSearchPJ(val);
			}
		} else if ( kCmdJSSearchEnd == cmd ) {
			if (_searchWindow && _searchWindow.contentWindow.handleSearchEnd) {
				_searchWindow.contentWindow.handleSearchEnd();
			}
		} else if ( kCmdJSConnectEnd == cmd ) {
			if (_searchWindow && _searchWindow.contentWindow.handleConnectEnd) {
				_searchWindow.contentWindow.handleConnectEnd();
			}
		} else if ( kCmdJSDisconnectEnd == cmd ) {
			
			closeWindowWithIgnorePjCtrlCleanup(_toolbarWindow);
			_toolbarWindow = null;
			closeDialogWindow(); 
			closePJInfoWindow();
			if (_searchWindow && _searchWindow.contentWindow.handleDisconnectEnd) {
				_searchWindow.contentWindow.handleDisconnectEnd();
			}
            _pjCtrlDisconnectProcessing = false;
		} else if ( kCmdJSConnectionError == cmd ) {
			var pjerror = val["pjerror"];
			var detail = val["pjerrordetail"];
			if (_searchWindow && _searchWindow.contentWindow.handleConnectionError) {
				_searchWindow.contentWindow.handleConnectionError(pjerror, detail);
			}
		} else if ( kCmdJSProjectionConfig == cmd ) {
			setProjectionConfig(val["pjConfig"]);
		} else if ( kCmdJSCaptureStart == cmd ) {
			
			
			
		} else if ( cmd == kCmdJSCaptureCancel ) {
			
			
			
		} else if ( cmd == kCmdJSPreConnectSearchPJ ) {
			if (_searchWindow && _searchWindow.contentWindow.handlePreConnectSearchPJ) {
				_searchWindow.contentWindow.handlePreConnectSearchPJ(val);
			}
		} else if ( cmd == kCmdJSCleanUpEnd ) {
			handleCleanUpEnd();
		}
	}
	
	if ( 0 < msg.length ) {
		logMsg( msg );
	}
};


function handleError(event) {
	logBackGroundMessage("call handleError");
	updateStatus();
};


function handleCrash(event) {
	logBackGroundMessage("call handleCrash");
	updateStatus();

	
	chrome.runtime.reload();
};


function closeAllWindow() {
	logBackGroundMessage("call closeAllWindow.");
	
	if (isSearchWindowOpen()) {
		closeWindowWithIgnorePjCtrlCleanup(_searchWindow);
	}
	_searchWindow = null;
	
	if (isToolbarWindowOpen()) {
		closeWindowWithIgnorePjCtrlCleanup(_toolbarWindow);
	}
	_toolbarWindow = null;
	
	if (_eulaWindow && !_eulaWindow.contentWindow.closed) {
		closeWindowWithIgnorePjCtrlCleanup(_eulaWindow);
	}
	_eulaWindow = null;
	
	if (_splashWindow && !_splashWindow.contentWindow.closed) {
		closeWindowWithIgnorePjCtrlCleanup(_splashWindow);
	}
	_splashWindow = null;

	if (_supportWindow && !_supportWindow.contentWindow.closed) {
		closeWindowWithIgnorePjCtrlCleanup(_supportWindow);
	}
	_supportWindow = null;
	
	if (_pjinfoWindow && !_pjinfoWindow.contentWindow.closed) {
		closeWindowWithIgnorePjCtrlCleanup(_pjinfoWindow);
	}
	_pjinfoWindow = null;
	
	
	
	
	
	
}


function handleCleanUpEnd() {
	logBackGroundMessage("call handleCleanUpEnd.");

	closeAllWindow();
	
	deletePjController();
	
	_pjCtrlCleanupProcessing = false;
}


function createPjController() {
	logBackGroundMessage("call createPjController. this=" + this);
	
	if (_pjController === null) {
		logBackGroundMessage("create PjController.");
		_pjController = new PjController();

        if (_pjController !== null) {
            logBackGroundMessage("setup PjController.");
            _pjController.setup(moduleLoadStart, moduleLoadProgress, moduleDidLoad, handleMessage, handleError, handleCrash);
        }
    }
}


function deletePjController() {
	logBackGroundMessage("call deletePjController.");
	
	if (_pjController != null) {
		_pjController.cleanup();
		
		delete _pjController;
		_pjController = null;
	}
}


function postMessageToPjController(cmd, key, value) {
	logBackGroundMessage("postMessageToPjController : " + "cmd=" + cmd + "key=" + key + "value=" + value);
	if (_pjController == null) {
		return;
	}
	_pjController.postMessage(cmd, key, value);
}


function getPjControllerStatus() {
	logBackGroundMessage("getPjControllerStatus");
	if (_pjController == null) {
		return;
	}
	
	return _pjController.getStatus();
}


function setConnectedPJList(pjList) {
	_connectedPJList = pjList;
}


function getConnectedPJList() {
	
	
	
	
	
	
	
	
	return _connectedPJList;
}
