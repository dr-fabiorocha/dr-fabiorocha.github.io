onload = function() {
	localizeControls();
};