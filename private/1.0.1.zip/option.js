var _optionSettings = null;

const kTabIndex_usersettings_userName           = 0x01; 
const kTabIndex_usersettings_pjList             = 0x02; 
const kTabIndex_usersettings                    = kTabIndex_usersettings_userName | kTabIndex_usersettings_pjList; 
const kTabIndex_performancesettings_bandlist    = 0x04; 
const kTabIndex_performancesettings_LowerReso   = 0x08; 
const kTabIndex_performancesettings             = kTabIndex_performancesettings_bandlist | kTabIndex_performancesettings_LowerReso; 


onload = function() {
	localizeControls();
	initializeControls();
	attachListeners();
	
	updateDeleteButton();

}


function updateProjectorList(list) {
	logMsg("call updateProjectorList."+list);
	
	var pjSelect = document.getElementById("pjlist");
	if (pjSelect) {
		
		for (var index = pjSelect.childNodes.length - 1; index >=0; index--) {
			pjSelect.removeChild(pjSelect.childNodes[index]);
		}
		
		for (var pjIndex = 0; pjIndex < list.length; pjIndex++) {
			var option = document.createElement("option");
			if (option) {
				option.value = pjIndex;
				option.className = "pjlistoption";
				option.title = list[pjIndex].ip + " " + list[pjIndex].name;
				option.innerHTML = list[pjIndex].ip + " " + list[pjIndex].name;
				pjSelect.appendChild(option);
			}
		}
	}
}


function updateControls(updateTabIndex) {
    if (updateTabIndex & kTabIndex_usersettings_userName) {
        logMsg("call updateUserSettingControls:userName.");
        
        
        document.getElementById("user_name").value = _optionSettings.UserName;
    }
    if (updateTabIndex & kTabIndex_usersettings_pjList) {
        logMsg("call updateUserSettingControls:pjList.");
        
        
        updateProjectorList(_optionSettings.SearchList);
        
        updateDeleteButton();
    }
    if (updateTabIndex & kTabIndex_performancesettings_bandlist) {
        logMsg("call updatePerformanceSettingControls:bandlist.");
        
        
        document.getElementById("band_list").value = _optionSettings.Band;
    }
    if (updateTabIndex & kTabIndex_performancesettings_LowerReso) {
        logMsg("call updatePerformanceSettingControls:LowerReso.");
        
        
        document.getElementById("lower_resolution").checked = (_optionSettings.LowerResolution == kOptionLowerResolutionOff ? false : true);
        document.getElementById("lower_resolution").disabled = (kOptionBand512Kbps === _optionSettings.Band || kOptionBand256Kbps === _optionSettings.Band);
    }
}


function initializeControls() {
	logMsg("call initializeControls.");
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg._syncSettings === "undefined") {
			return;
		}
		_optionSettings = jQuery.extend(true, {}, bg._syncSettings);
		updateControls(kTabIndex_usersettings | kTabIndex_performancesettings);
	});
}


function attachTabListeners() {
	
	var menu = document.getElementById("option_settings_tab_menu");
	var listItem = menu.getElementsByTagName("li");
	var menus = menu.getElementsByTagName("a");
	var current; 
	tabInitialize = function(listItem, menuItem, index) {
		
		var id = menuItem.hash.slice(1);
		var page = document.getElementById(id);
		
		if (!current){
			
			
			current = {page:page, menu:menuItem, list:listItem};
			
			page.style.display = "block";
			menuItem.className = "active";
			listItem.className = "active";
		} else {
			page.style.display = "none";
		}
		
		menuItem.onclick = function(){
			
			
			if (id == "band_settings_page") {
				if (!isValidUserName()) {
					return false;
				}
			}
			
			
			current.page.style.display = "none";
			current.menu.className = "";
			current.list.className = "";
			
			page.style.display = "block";
			menuItem.className = "active";
			listItem.className = "active";
			
			current.page = page;
			current.menu = menuItem;
			current.list = listItem;
			return false;
		};
	}
	for (var menuIndex = 0; menuIndex < menus.length; menuIndex++){
		tabInitialize(listItem[menuIndex] ,menus[menuIndex], menuIndex);
	}
}


function attachListeners() {
	logMsg("call attachListeners.");
	
	
	attachTabListeners();
	
	
	document.getElementById("user_name").addEventListener("change", doChangeUserName);
	document.getElementById("pjlist").addEventListener("change", doChangePJList);
	document.getElementById("select_all_button").addEventListener("click", doSelectAll);
	document.getElementById("delete_button").addEventListener("click", doDelete);
	
	
	document.getElementById("band_list").addEventListener("change", doChangeBand);
	document.getElementById("lower_resolution").addEventListener("change", doChangeLowerResolution);
	
	
	document.getElementById("reset_button").addEventListener("click", doReset);
	document.getElementById("ok_button").addEventListener("click", doOK);
	document.getElementById("cancel_button").addEventListener("click", doCancel);
	
}


function doSelectAll() {
	logMsg("call doSelectAll.");

	var pjSelect = document.getElementById("pjlist");
	if (pjSelect) {
		for (var index = 0; index < pjSelect.childNodes.length; index++) {
			pjSelect.childNodes[index].selected = true;
		}
        
        if (index > 0) {
            updateDeleteButton();
        }
		pjSelect.focus();
	}
}

function deleteSelectedProjectorList() {
	logMsg("call deleteSelectedProjectorList.");
	
	var pjSelect = document.getElementById("pjlist");
	if (pjSelect) {
		
		for (var index = pjSelect.childNodes.length - 1; index >=0; index--) {
			if (pjSelect.childNodes[index].selected == true) {
				_optionSettings.SearchList.splice(index, 1);
			}
		}
	}
	
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg._syncSettings.SearchList) {
			bg._syncSettings.SearchList.splice(0,bg._syncSettings.SearchList.length);
			bg._syncSettings.SearchList = _optionSettings.SearchList.concat();

		}
	});
	
	
	updateProjectorList(_optionSettings.SearchList);
	updateDeleteButton();
}


function deleteCancel() {
	logMsg("call deleteCancel.");
}


function isSelectedPJListItem() {
	
	var hasSelectItem = false;
	var pjSelect = document.getElementById("pjlist");
	if (pjSelect) {
		for (var index = pjSelect.childNodes.length - 1; index >=0; index--) {
			if (pjSelect.childNodes[index].selected == true) {
				hasSelectItem = true;
				break;
			}
		}
	}
	return hasSelectItem;
}


function doDelete() {
	logMsg("call doDelete.");
	

	
	if (isSelectedPJListItem()) {
		showDialogOnCurrentWindow(LZD_DELETE_HISTORY, deleteSelectedProjectorList, deleteCancel);
	}
}


function doChangeUserName() {
	logMsg("call doChangeUserName.");
	
	_optionSettings.UserName = document.getElementById("user_name").value;
	
	updateControls(kTabIndex_usersettings_userName);
}


function updateDeleteButton() {
	logMsg("call updateDeleteButton.");
	
	if (isSelectedPJListItem()) {
		document.getElementById("delete_button").disabled = false;
	} else {
		document.getElementById("delete_button").disabled = true;
	}
}


function doChangePJList() {
	logMsg("call doChangePJList.");
	
	updateDeleteButton();
}


function doChangeBand() {
	logMsg("call doChangeBand.");
	
	_optionSettings.Band = document.getElementById("band_list").value;
	
	updateControls(kTabIndex_performancesettings);
}


function doChangeLowerResolution() {
	logMsg("call doChangeLowerResolution.");

	_optionSettings.LowerResolution = (document.getElementById("lower_resolution").checked ? kOptionLowerResolutionOn : kOptionLowerResolutionOff);
	
	updateControls(kTabIndex_performancesettings);
}


function doReset() {
	logMsg("call doReset.");
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg.getDefaultSettings == "undefined") {
			return;
		}
		
		
		bg.getDefaultSettings(function(defaultSettings) {
			if (!defaultSettings) {
				return;
			}
			
			
			_optionSettings.UserName = defaultSettings.UserName;
			_optionSettings.Band = defaultSettings.Band;
			_optionSettings.LowerResolution = defaultSettings.LowerResolution;

			updateControls(kTabIndex_usersettings | kTabIndex_performancesettings);
		});
		
	});
}


function isValidUserName() {
	var userName = document.getElementById("user_name").value;
	if (userName == "") {
		showDialogOnCurrentWindow(LZD_ERR_STR_USER_NAME_INPUT, function() {
			
		},null);
		return false;
	} else if (userName.length > 32) {
		showDialogOnCurrentWindow(LZD_ERR_STR_PROFILE_NAME_MAX_OVER, null, function() {
			
		},null);
		return false;
	}
	
	return true;
}


function doOK() {
	logMsg("call doOK.");

	
	if (!isValidUserName()) {
		return;
	}
	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg._syncSettings === "undefined") {
			return;
		}
		
		
		bg._syncSettings.UserName = document.getElementById("user_name").value;
		
		bg._syncSettings.Band = document.getElementById("band_list").value;
		
		var isChecked = document.getElementById("lower_resolution").checked;
		bg._syncSettings.LowerResolution = (true === isChecked ? kOptionLowerResolutionOn : kOptionLowerResolutionOff);
		
		
		
		
		chrome.app.window.current().close();
		
	});
}


function doCancel() {
	logMsg("call doCancel.");
	
	chrome.app.window.current().close();
	
	
}


function onDisplayChanged(displayRotationOld, displayRotationNew) {
	logMsg("Display Changed - option");

	
	if (displayRotationOld != displayRotationNew) {
		logMsg("Display Rotation Changed frome "+ displayRotationOld +"℃ to "+ displayRotationNew +"℃");

		var active_element = document.activeElement;

		
		if ( active_element.id == "user_name") {

			active_element.blur();

			
			setTimeout(function () {
				active_element.focus();
			}, 500 );
		}
	}

}
