
function eula_ok() {
　　chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
     if (backgroundPage.onEulaAgree === 'undefined') {
      
       return;
     }
　　　backgroundPage.onEulaAgree();
　　});
}


function eula_cancel() {
　　chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
     if (backgroundPage.onEulaDisagree === 'undefined') {
      
       return;
     }
     
　　　backgroundPage.onEulaDisagree();
　　});
}


onload = function() {
  localizeControls();
	
  
  var eula_ok_button = document.getElementById('eula_ok');
  if (eula_ok_button) {
    eula_ok_button.onclick = eula_ok;
  }
  
  var eula_cancel_button = document.getElementById('eula_cancel');
  if (eula_cancel_button) {
    eula_cancel_button.onclick = eula_cancel;
	eula_cancel_button.focus();
  }
}
