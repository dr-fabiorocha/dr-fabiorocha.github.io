"use strict";

(function() {
	var PjController = function() {
		logMsg("call PjController Constructor.");
 
		this.naclListener_ = null;
		this.naclEmbed_ = null;
		this.naclModule_ = null;
 
		this.moduleDidLoad_ = null;
		this.handleMessage_ = null;
		this.handleError_ = null;
		this.handleCrash_ = null;
 
		this.naclStatus_ = 'NO-STATUS';
	};
 
	
	
	
	PjController.prototype.setup = function(moduleDidLoadStart, moduleLoadProgress, moduleDidLoad, handleMessage, handleError, handleCrash) {
		logMsg("call PjController.prototype.setup.");
		this.moduleDidLoadStart_ = moduleDidLoadStart;
		this.moduleLoadProgress_ = moduleLoadProgress;
		this.moduleDidLoad_ = moduleDidLoad;
		this.handleMessage_ = handleMessage;
		this.handleError_ = handleError;
		this.handleCrash_ = handleCrash;
 
		var elements = loadNaClModule.call(this);
		this.naclListener_ = elements.listener;
		this.naclEmbed_ = elements.embed;
 
		this.naclListener_.addEventListener('loadstart',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");

												this.naclStatus_ = 'LOADSTART';
											
												
												if (this.moduleDidLoadStart_ !== null) {
													this.moduleDidLoadStart_(event);
												}
											}.bind(this), true);
 
		this.naclListener_.addEventListener('progress',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");

												var loadPercent = 0.0;
												var loadPercentString;
											
												if (event.lengthComputable && event.total > 0) {
													loadPercent = event.loaded / event.total * 100.0;
													loadPercentString = loadPercent + '%';
													logMsg('progress: ' + event.url + ' ' + loadPercentString +
																	  ' (' + event.loaded + ' of ' + event.total + ' bytes)');
												} else {
													logMsg('progress: Computing...');
												}

												this.naclStatus_ = 'PROGRESS';
											
												
												if (this.moduleLoadProgress_ !== null) {
													this.moduleLoadProgress_(event);
												}
											}.bind(this), true);
 
		this.naclListener_.addEventListener('load',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");
											
												
												this.naclModule_ = document.getElementById('nacl_module');
												this.naclStatus_ = 'RUNNING';
												
												if (this.moduleDidLoad_ !== null) {
													this.moduleDidLoad_();
												}
											}.bind(this), true);
 
		this.naclListener_.addEventListener('message',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");

												this.naclStatus_ = 'RUNNING';
											
												
												if (this.handleMessage_ !== null) {
													this.handleMessage_(event);
												}
											}.bind(this), true);
 
		this.naclListener_.addEventListener('error',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");
											
												this.naclStatus_ = 'ERROR [' + this.naclModule_.lastError + ']';
											
												
												if (this.handleError_ !== null) {
													this.handleError_(event);
												}
											}.bind(this), true);
 
		this.naclListener_.addEventListener('crash',
											function(event) {
												logMsg("call \"" + event.type + "\" event from NaClModule.  [readyState:" + this.naclEmbed_.readyState + "]");
											
												if (this.naclModule_.exitStatus == -1) {
													this.naclStatus_ = 'CRASHED';
												} else {
													this.naclStatus_ = 'EXITED [' + this.naclModule_.exitStatus + ']';
												}

												
												if (this.handleCrash_ !== null) {
													this.handleCrash_(event);
												}
											}.bind(this), true);
	};
 
	
	PjController.prototype.cleanup = function() {
		logMsg("call PjController.prototype.cleanup.");
 
		this.moduleDidLoad_ = null;
		this.handleMessage_ = null;
		this.handleError_ = null;
		this.handleCrash_ = null;

		var elements = unloadNaClModule.call(this);
		this.naclListener_ = elements.listener;
		this.naclEmbed_ = elements.embed;
	};

	
	PjController.prototype.postMessage = function(cmdvalue, keyvalue, data) {
		logMsg("call PjController.prototype.postMessage.[cmd:" + cmdvalue + " key:" + keyvalue + " value:" + data + "]");
 
		if (this.naclEmbed_ == null) {
			return;
		}
 
		this.naclEmbed_.postMessage({cmd: cmdvalue, key: keyvalue, value: data});
		return;
	};
 
	
	PjController.prototype.getStatus = function() {
		return this.naclStatus_;
	};
	
	
	
	
	var loadNaClModule = function() {
		logMsg("call loadNaClModule.");
 
		
		var listener = document.createElement('div');
		listener.id = 'nacl_listener';
		document.body.appendChild(listener);
 
		var embed = document.createElement('embed');
		
		embed.setAttribute('name', 'nacl_module');
		embed.setAttribute('id', 'nacl_module');
		embed.setAttribute('width', 0);
		embed.setAttribute('height', 0);
		
		
		
		
		embed.setAttribute('path', 'pnacl/Release');
		embed.setAttribute('src', 'pnacl/Release/pjcontroller.nmf');
		embed.setAttribute('type', 'application/x-pnacl');
		listener.appendChild(embed);

        
        
        
        embed.offsetTop;
 
		return {
				listener: listener,
				embed: embed
				};
	};
 
	
	var unloadNaClModule = function() {
		logMsg("call unloadNaClModule.");
 
		var listener = document.getElementById('nacl_listener');
		if (listener) {
			var embed = document.getElementById('nacl_module');
			if (embed) {
				listener.removeChild(embed);
			}
			document.body.removeChild(listener);
		}
 
		return {
			listener: null,
			embed: null
		};
	};
 
	
	window.PjController = PjController;

})();