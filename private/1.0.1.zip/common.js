const kCmdInitParams = 0;

const kCmdSetLogLevel = 1;
const kCmdFileSystem = 2;

const kCmdSearchStart = 3;
const kCmdSearchListAction = 4;
const kCmdSearchStop = 5;

const kCmdCaptureStart = 6;
const kCmdSetUserName = 7;
const kCmdCliMultiHigh = 8;
const kCmdCliNetwork = 9;
const kCmdBandControl = 10;
const kCmdSendStreamData = 11;
const kCmdProjection = 12;
const kCmdScreenProjection = 13;

const kCmdCaptureCancel = 14;
const kCmdRemovePJSearchInfo = 15;

const kCmdDisplayChanged = 16;
const kCmdPauseGetFrame = 17;
const kCmdNicList = 18;

const kCmdCleanUp = 19;


const kCmdJSSearchPJ = "js_search_pj";
const kCmdJSSearchEnd = "js_search_end";
const kCmdJSConnectEnd = "js_connect_end";
const kCmdJSDisconnectEnd = "js_disconnect_end";
const kCmdJSConnectionError = "js_connect_error";
const kCmdJSProjectionConfig = "js_projection_config";
const kCmdJSCaptureStart = "js_capture_start";
const kCmdJSCaptureCancel = "js_capture_cancel";
const kCmdJSPreConnectSearchPJ = "js_preconnectsearch_pj";
const kCmdJSCleanUpEnd = "js_cleanup_end";

const kPJIDKey = "kPJIDKey";
const kPJNameKey = "kPJNameKey";
const kPJIPAddressKey = "kPJIPAddressKey";
const kPJUniqInfoKey = "kPJUniqInfoKey";
const kPJStatusKey = "kPJStatusKey";
const kPJKeywordStringKey = "kPJKeywordStringKey";
const kPJCheckKey = "kPJCheckKey";
const kPJSSIDKey = "kPJSSIDKey";

const kPJErrorKey = "kPJErrorKey";
const kErrorSuccess				= 0;
const kErrorCheckSuccess		= 1;

const kErrorJoinExceedMax		= 66;
const kErrorKeyword				= 68;
const kErrorPjAnotherConUsed	= 70;
const kErrorNoResponse			= 72;
const kErrorNetwork				= 73;
const kErrorConnect				= 74;
const kErrorDisconProjector		= 76;
const kErrorDisconModerator		= 77;
const kErrorDisconClient		= 78;
const kErrorUnknown				= 83;

const kErrorPreConnectSearch	= 100;



const kOptionBandNone = "0";
const kOptionBand4Mbps = "1";
const kOptionBand2Mbps = "2";
const kOptionBand1Mbps = "3";
const kOptionBand512Kbps = "4";
const kOptionBand256Kbps = "5";
const kOptionBandDefault = kOptionBandNone;

const kOptionLowerResolutionOff = "0";
const kOptionLowerResolutionOn = "1";
const kOptionLowerResolutionDefault = kOptionLowerResolutionOff;

const kProj_status_notfound            = 0;     
const kProj_status_nouse               = 1;     
const kProj_status_using_np            = 2;     
const kProj_status_using_notinterruption = 3;	
const kProj_status_using_mpc           = 4;     
const kProj_status_using_mpc_mirror    = 5;     
const kProj_status_using_mpc_max       = 6;     
const kProj_status_using_mpc_mirror_max = 7;    
const kProj_status_using_other         = 8;     
const kProj_status_search              = 9;     
const kProj_status_update              = 10;	
const kProj_status_internal_nosupport  = 11;    


function PostMessage(cmd, key, value) {








	
	chrome.runtime.getBackgroundPage(function(bg) {
		if (bg.postMessageToPjController === 'undefined') {
			return;
		}
		bg.postMessageToPjController(cmd, key, value);
	});
}


function logMsg(msg) {
    chrome.runtime.getBackgroundPage(function(bg) {
        if (bg.updateLogMessage(msg) == false) {
            
        }
    });
}


function logClear() {
    chrome.runtime.getBackgroundPage(function(bg) {
        bg.clearLogMessage();
    });
}


function getChromeVersion() {
	var chromeVersion = 0;
	
	var nAgt = navigator.userAgent;
	var pos = nAgt.indexOf("Chrome") + 7;
	var subStr = nAgt.substring(pos);
	pos = subStr.indexOf(" ");
	
	chromeVersion = subStr.substring(0,pos);
	
	return chromeVersion;
}


function localizeControls(){
	
	logMsg("call localizeControls().");

	
	var selector = "message-id";
	var elementList = document.querySelectorAll("[" + selector + "]");
	
	for (var i = 0; i < elementList.length; i++) {
		var element = elementList[i];
		
		var messageID = element.getAttribute(selector);
		var messageText = chrome.i18n.getMessage(messageID);
		
		var textNode = document.createTextNode(messageText);
		element.appendChild(textNode);
	}
	
	
	selector = "tooltip-id";
	elementList = document.querySelectorAll("[" + selector + "]");
	for (var i = 0; i < elementList.length; i++) {
		var element = elementList[i];
		
		var messageID = element.getAttribute(selector);
		var messageText = chrome.i18n.getMessage(messageID);

		element.title = messageText;
	}
}

