
function doClose(event) {
	logMsg("call doClose!!");
	
	chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
		if (backgroundPage.closePJInfoWindow === 'undefined') {
			return;
		}
		backgroundPage.closePJInfoWindow();
	});
}


onload = function() {
	
	localizeControls();
	
	
	document.getElementById('close').addEventListener('click', doClose);
	
	
	chrome.runtime.getBackgroundPage(function ( backgroundPage ) {
		if (backgroundPage.getConnectedPJList === 'undefined') {
			return;
		}
		
		var ipAddressTitle = chrome.i18n.getMessage("LZD_COLUMN_IP_ADDRES");
		var keywordTitle = chrome.i18n.getMessage("LZD_CAP_INPUT_KEYWORD_KEYWORD");
		var pjInfosElement = document.getElementById("pjInfos");
		var pjList = backgroundPage.getConnectedPJList();
		
		var i=0;
		for(i=0; i < pjList.length; i++){
			var pjInfo = pjList[i];
			
			var pjKeywordString = null;
			if (pjInfo.kPJKeywordKey == 1) {
				pjKeywordString = pjInfo.kPJKeywordStringKey;
			} else {
				pjKeywordString = "----";
			}
			var pjInfoElement = document.createElement("fieldset");
			pjInfoElement.className = "pjInfo";
			pjInfoElement.innerHTML = 
				'<legend>' + pjInfo.kPJNameKey + '</legend>' +
				ipAddressTitle + ': ' + pjInfo.kPJIPAddressKey + '<br>' +   
				keywordTitle + ': ' + pjKeywordString;
			pjInfosElement.appendChild(pjInfoElement);
		}
	});
}
