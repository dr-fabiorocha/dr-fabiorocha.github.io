function local_txt(){
    var ui_lang = chrome.i18n.getUILanguage();
    
    var doc = document.getElementById("tx_support");
    if(doc != null){
        doc.innerHTML = chrome.i18n.getMessage("LZD_SUPPORT_TITLE");;
    }

    doc = document.getElementById("tx_help");
    if(doc != null){
        doc.innerHTML = chrome.i18n.getMessage("LZD_HELP");;
    }
    
    doc = document.getElementById("link_howto");
    if(doc != null){
        switch(ui_lang){
            case "ja":
                doc.innerHTML = "<A HREF=\"_locales/ja/howto.html\">" + chrome.i18n.getMessage("LZD_HOWTO") + "</A>";
                break;
            default:
                doc.innerHTML = "<A HREF=\"_locales/en/howto.html\">" + chrome.i18n.getMessage("LZD_HOWTO") + "</A>";
                break;
        }
    }    
    
    doc = document.getElementById("content_webguide");
    if(doc != null){
        if(ui_lang!="ja"){
            doc.innerHTML = "<LI><A HREF=\"" + chrome.i18n.getMessage("LZD_ONLINE_GUIDE_URL") + "\" target=_\"blank\">"
                            + chrome.i18n.getMessage("LZD_ONLINE_GUIDE") + "</A></LI>";
        }

        
    }    
    
    doc = document.getElementById("tx_about");
    if(doc != null){
        doc.innerHTML = chrome.i18n.getMessage("LZD_ABOUT");;
    }
    
    doc = document.getElementById("tx_license");
    if(doc != null){
        doc.innerHTML = chrome.i18n.getMessage("LZD_LICENSE");;
    }

    doc = document.getElementById("link_license");
    if(doc != null){
        doc.innerHTML = "<iframe id=\"license\" name=\"licese_iframe\" src=\"" + chrome.i18n.getMessage("LZD_LICENSE_FILE") + "\" frameborder=\"0\""
                        + "frameborder=\"0\" width=\"" + (480 - getCurrentScrollbarWidth()) + "px\" height=\"100px\" name=\"target_box\" ></iframe>";
    }
    
    doc = document.getElementById("tx_version");
    if(doc != null){
        doc.innerHTML = chrome.i18n.getMessage("LZD_VERSION");;
    }
	
	doc = document.getElementById("support_close");
	if(doc != null){
		var messageText = chrome.i18n.getMessage("LZD_BTN_CLOSE");
		var textNode = document.createTextNode(messageText);
		doc.appendChild(textNode);
	}

	doc = document.getElementById("support_back");
	if(doc != null){
		var messageText = chrome.i18n.getMessage("LZD_BTN_BACK");
		var textNode = document.createTextNode(messageText);
		doc.appendChild(textNode);
	}
}

function getCurrentScrollbarWidth(){
	var div  = document.createElement("div");

	var style = div.style;
	style.width      = "1px";
	style.height     = "1px";
	style.overflow   = "scroll";
	style.border     = "none";
	style.visibility = "hidden";

	var inner = div.cloneNode(false);
	div.appendChild(inner);
	document.body.appendChild(div);
	div.scrollTop = 100;
	var scrollbarWidth = div.scrollTop;
	document.body.removeChild(div);

	return scrollbarWidth;
}




function appinfo() {
   if(document.getElementById("ApplicationVersion")!=null){
	   document.getElementById("ApplicationVersion").innerHTML
        = chrome.runtime.getManifest().version;
   }
}

onload = function() {
	local_txt();
	appinfo();
	
	
	if (document.getElementById("support_close") != null) {
		document.getElementById("support_close").addEventListener('click', function(event) {
				chrome.app.window.current().close();
		});
	}

	
	if (document.getElementById("support_back") != null) {
		document.getElementById("support_back").addEventListener('click', function(event) {
                target_box.location = "menu.html";
        });
	}

	if (document.getElementById("page_support_parent_frame") != null) {
		
	} else {
		

		var current_page_is_support_top = false;

		if (document.getElementById("page_support_top") != null) {
			current_page_is_support_top = true;
		}

		var button_support_back = window.parent.document.getElementById("support_back");

		if(button_support_back != null){
			if (true == current_page_is_support_top){
				button_support_back.style.visibility="hidden";
			}
			else{
				button_support_back.style.visibility="visible";
			}
		}
	}

	if (document.getElementById("license") != null) {
		$('iframe').on('load', function(){
			
			$(this).height(this.contentWindow.document.documentElement.offsetHeight);
		}).trigger('load');
	}
};