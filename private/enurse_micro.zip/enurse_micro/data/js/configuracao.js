
		function atualiza_lista_redes()
		{

		

			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					document.getElementById('tbody').innerHTML = xhttp.responseText;
    				}
  			};
			xhttp.open("GET", "http://enurse.local/lista_wireless.php", true);
			xhttp.send();
		}
 			
		function myFun(e)
		{ 
			var target = e.target;
    
			if ( target.nodeName != 'TD' )  return;
			var columns = target.parentNode.getElementsByTagName( 'td' );
    
			document.getElementById('nome').value  = columns[ 0 ].innerHTML;

		}

		function envia_form ()
		{
			var xhttp = new XMLHttpRequest();
			var url =url = "http://10.1.1.1/conecta?nome="+document.getElementById('nome').value+"&senha="+document.getElementById('senha').value;
			xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					
					document.getElementById('dados_janela').innerHTML = xhttp.responseText;
    				}
  			};

			xhttp.open("GET", url, true);
			xhttp.send();
		}
		function inicializa ()
		{
        	atualiza_lista_redes();
			setInterval(function () {atualiza_lista_redes()}, 10000);
			document.getElementById('painel_principal').style.visibility="visible";
			document.getElementById('espera_carregamento').style.display = "none";
		}



