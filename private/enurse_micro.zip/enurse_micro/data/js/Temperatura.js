function Temperatura (ID, ID2)
{
	var vetorAmostras = Array();
	var qtdPontos;
	var canvas = document.getElementById(ID);
    var ctx    = canvas.getContext('2d');
	var tempMin=20;
	var tempMax=40;

    this.resize = function ()
    {
        this.setHeightWidth( (window.innerHeight-150), window.innerWidth);
        alert(window.innerWidth)
    };
    this.setHeightWidth=  function(H,W)
	{
		qtdPontos    = W;
        canvas.style.width ='100%';
        canvas.style.height='100%';
        canvas.width  = W;
        canvas.height = H;
	};
	this.novaAmostra=  function(amostra)
	{
	    document.getElementById(ID2).innerHTML = amostra+"&#8451;";
		
		if (vetorAmostras.length==qtdPontos)   vetorAmostras.splice(0, 1);
		vetorAmostras.push( amostra ) ;
		
		this.atualizaGrafico();
	};	

	this.atualizaGrafico=  function()
	{
		ctx.clearRect(0, 0, canvas.width,canvas.height);
		ctx.strokeStyle = "blue"; 
		ctx.lineWidth   = "0";
  	ctx.fillStyle   = 'blue';
		
		var coord_y;
			//var canvasLegenda = document.getElementById("legendaTemperatura");

			//var ctxLegenda    = canvasLegenda.getContext("2d");
			//ctxLegenda.clearRect(0, 0, canvasLegenda.width,canvasLegenda.height);	
			///ctxLegenda.font = "12px Arial";
			// ctxLegenda.fillStyle = "black";

			//ctxLegenda.textAlign = "center";
			//ctxLegenda.fillText("40", 10, 10);
			//ctxLegenda.fillText("20", 10, canvasLegenda.height);

      var escala = canvas.height/30;
      var y_old=20;
			for (var coord_x = 1; coord_x< qtdPontos; coord_x++)
			{
                coord_y =   vetorAmostras[coord_x];
                //coord_y=21;
                coord_y = (coord_y-20)*escala;
                coord_y =   canvas.height - coord_y;
		 		 ctx.beginPath();
         ctx.moveTo(coord_x-1,y_old);
         ctx.lineTo(coord_x,coord_y);
         y_old = coord_y;
ctx.stroke();

			}	
                ctx.fillText("50",0,10);
                ctx.fillText("20",0,canvas.height);

ctx.stroke();



		
	};
}
