
  function Settings () {
    this.credentials = {email: '', password: ''}
    this.config = {showMap: {points: true, busStop: true}, mapType: 1}

    if (!localStorage.getItem('configPoints')) localStorage.setItem('configPoints', this.config.showMap.points.toString())
    if (!localStorage.getItem('configBusStop')) localStorage.setItem('configBusStop', this.config.showMap.busStop.toString())
    if (!localStorage.getItem('configMapType')) localStorage.setItem('configMapType', this.config.mapType)

    this.config.showMap.points = (localStorage.getItem('configPoints') === 'true')
    this.config.showMap.busStop = (localStorage.getItem('configBusStop') === 'true')
    this.config.mapType = parseInt(localStorage.getItem('configMapType'))
    if (!localStorage.getItem('credEmail')) localStorage.setItem('credEmail', this.credentials.email)
    if (!localStorage.getItem('credPassword')) localStorage.setItem('credPassword', this.credentials.password)

    this.credentials.password = localStorage.getItem('credPassword')
    this.credentials.email = localStorage.getItem('credEmail')
    this.registra()
  }

  Settings.prototype.registra = function () {
    PubSub.subscribe('initialize', function (msg, data) {
      LOG('>>Settings initialize')
      try {
        PubSub.publish('updateSettings', {origin: 'settings', value: this.config})
        PubSub.publish('updateCredentials', {origin: 'settings', value: this.credentials})
      } catch (e) {

      }
    }.bind(this))
    PubSub.subscribe('MapsCarregado', function (msg, credentials) {
     LOG('>>Settings MapsCarregado')
     PubSub.publish('updateSettings', {origin: 'settings', value: this.config})


    }.bind(this))
    PubSub.subscribe('updateSettings', function (msg, data) {
      if (data.origin != 'settings') {
        LOG('>>settings updateSettings')
        let obj = Object.assign(this.config, data.value)
        this.config = obj

        localStorage.setItem('configPoints', this.config.showMap.points.toString())
        localStorage.setItem('configBusStop', this.config.showMap.busStop.toString())
        localStorage.setItem('configMapType', this.config.mapType)
      }
    }.bind(this))

    PubSub.subscribe('updateCredentials', function (msg, data) {
      if (data.origin != 'settings') {
        LOG('>>settings updateCredentials')

        this.credentials = data.value
        localStorage.setItem('credEmail', this.credentials.email)
        localStorage.setItem('credPassword', this.credentials.password)
      }
    }.bind(this))
  }

  Settings.prototype.get = function (a) {
    switch (a) {
      case 'credentials':
        return this.credentials
      case 'config':
        return this.config
      default:
        LOG('Settings.prototype.get')
    }
  }

  // Update

  Settings.prototype.validCredentials = function () {
    if ((this.credentials.password !== '') && (this.credentials.email !== '')) { return true } else return false
  }
  Settings.prototype.set = function (a, value) {
    switch (a) {
      case 'credentials':
        this.credentials = value
        localStorage.setItem('credEmail', this.credentials.email)
        localStorage.setItem('credPassword', this.credentials.password)
        break
      default:
        LOG('Settings.prototype.set ' + a + '  ' + value)
    }
  }
