
'use strict'

var elSetFr = document.querySelector('.set-en');
var elSetEnUs = document.querySelector('.set-pt-br');
var defaultLocale = 'pt-br';

function setupHTML() {
  var pref = (phonon.i18n().getPreference() ? phonon.i18n().getPreference() : 'not used');
  phonon.i18n().bind();
}

var setPreference = function (evt) {
  var target = evt.target;
  var lang = target.getAttribute('data-l');
  if(lang) {
    phonon.updateLocale(lang);
  }
};






function Ui (releaseInfo) {
         LOG('>>Ui>create')

  this.releaseInfo = releaseInfo
  this.appPhonon        = null
  phonon.options({
    navigator: {
      defaultPage: 'home',
      defaultTemplateExtension: 'html',
      animatePages: false,
      enableBrowserBackButton: true,
      templateRootDirectory: './'
    },
     i18n: {
    directory: 'res/lang/',
    localeFallback: defaultLocale,
    localePreferred: 'pt'
    }
  })
  this.registra()
  this.appPhonon = phonon.navigator()
  setupHTML()

  this.appPhonon.start()

 
 

  O('botaoInformacoesRetorna').addEventListener('click', this.retorna.bind(this), false)
  O('botaoConfiguracoesRetorna').addEventListener('click', this.retorna.bind(this), false)
  O('botaoConfiguracoesconfirma').addEventListener('click', this.configuracoesconfirma.bind(this), false)

  

 
  

}

Ui.prototype.configuracoesconfirma = function () {
  let dados={nome:'',data_nascimento:'',lingua:''}
  let nsc={dia:'',mes:'',ano:''}
  dados.nome            = O('Configuracoes_nome').value
  nsc.dia = O('nascimento.day').value
  nsc.mes = O('nascimento.month').value
  nsc.ano = O('nascimento.year').value
  
  dados.data_nascimento = nsc
  dados.lingua          = O('Configuracoes_lingua').value
  this.configuraLingua(dados.lingua)
  PubSub.publish('settings', {origin: 'Ui',dados:dados})
   phonon.panel('#CONFIGURACOES').close();
}

Ui.prototype.retorna = function (evt) {
     phonon.sidePanel('#MENU').close()
     phonon.panel('#CONFIGURACOES').close();
     phonon.panel('#INFORMACOES').close();
}


// -------------------- Registra funcoes ------------------------
Ui.prototype.registra = function () {
  // inicializa
  PubSub.subscribe('initialize', function (msg, data) {
    LOG('>>Inicializa Ui')

    
  }.bind(this))


  PubSub.subscribe('settings', function (msg, informacao) {

    {
      LOG('>>Ui > recebeu settings')
      try {
      } catch (e) {}
    }
  }.bind(this))

}
