"use strict";
var usa_log_remoto=""


var userInterface
var temperatura
var isCordovaApp = true




function fail(e) {
  console.dir(e);
}

function gotFile(fileEntry) {

  fileEntry.file(function(file) {
    var reader = new FileReader();

    reader.onloadend = function(e) {
      varCSS = this.result;
    }

    reader.readAsText(file);
  });

}


function Start () {
  if (typeof(cordova) == "object") 
  {
    
    isCordovaApp = true
  }
  else isCordovaApp=false


  this.initialize()
}
Start.prototype.pre = function () {
        LOG('Disparou o onDeviceReady')
        this.onDeviceReady()

}

Start.prototype.initialize = function () {


   if (isCordovaApp==true)
   {
        document.addEventListener('deviceready', this.pre.bind(this), false);
        document.documentElement.style.overflow = 'hidden'

   }
   else {
      this.onDeviceReady()
    }
}

Start.prototype.onDeviceReady = function () {




  LOG('START')

  userInterface = new Ui(this.releaseInfo)
  temperatura   = new Temperatura('temperatura','currentTemp')
    temperatura.resize();
  setInterval(function(){
    temperatura.novaAmostra(parseInt(Math.random()*30)+20)
  },1000)
  PubSub.publish('initialize','')



 
}.bind(this)
var app = new Start()
