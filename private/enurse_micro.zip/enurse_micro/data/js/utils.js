var SERVER="http://10.1.1.125:20000";

function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}


function LOG_REMOTO(msg)
{
  var request;
  
  request = new XMLHttpRequest();
  
  if (request) {
    request.open('POST', SERVER , true);
    request.setRequestHeader("Content-type", "application/json");    
    request.send( JSON.stringify({data:'[' + (new Date()).toLocaleTimeString() + '] ',msg:msg}) );
  }
}

Date.prototype.toDatetimeLocal =
  function toDatetimeLocal() {
    var
      date = this,
      ten = function (i) {
        return (i < 10 ? '0' : '') + i;
      },
      YYYY = date.getFullYear(),
      MM = ten(date.getMonth() + 1),
      DD = ten(date.getDate()),
      HH = ten(date.getHours()),
      II = ten(date.getMinutes()),
      SS = ten(date.getSeconds())
    ;
    return YYYY + '-' + MM + '-' + DD + 'T' +
             HH + ':' + II + ':' + SS;
  };

function LOG (msg) {

 switch (usa_log_remoto)
 {
    case 'console': 
                  console.log('[' + (new Date()).toLocaleTimeString() + '] ' + msg)
                  break;
    case 'full': 
                  LOG_REMOTO(msg)
                  console.log('[' + (new Date()).toLocaleTimeString() + '] ' + msg)
                  break;
   case 'remoto':
                  LOG_REMOTO(msg)
 }
 
}
function O(id) {
    return document.getElementById(id)
}
